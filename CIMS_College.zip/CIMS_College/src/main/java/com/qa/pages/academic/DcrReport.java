package com.qa.pages.academic;

import java.io.BufferedInputStream;
import java.net.URL;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class DcrReport extends BaseClass{
	
	public DcrReport(WebDriver rdriver)
	{
		driver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy (id = "DETAILED") private WebElement DETAILED;
	@FindBy (id = "ddlSession") private WebElement ddlSession;
	@FindBy (id = "ddlReceiptType") private WebElement ddlReceiptType;
	@FindBy (id = "ddlCashBookType") private WebElement ddlCashBookType;
	@FindBy (id = "txtDateFrom") private WebElement DateFrom;
	@FindBy (id = "txtDateTo") private WebElement DateTo;
	@FindBy (id = "btnReport") private WebElement btnReport;
	
	public DcrReport DETAILED() {
		System.out.println("Select Report Format");
		click(DETAILED);
		return this;
	}
	
	public DcrReport ddlSession() {
		System.out.println("Select SESSION 2022-2023");
		Select ddl = new Select(ddlSession);
		ddl.selectByVisibleText("SESSION 2022-2023");
		return this;
	}
	
	public DcrReport ddlReceiptType() {
		System.out.println("Select ddlReceiptType - ADMISSION,NEXT INSTALLMENT,OTHER FEES");
		Select ddl = new Select(ddlReceiptType);
		ddl.selectByVisibleText("ADMISSION,NEXT INSTALLMENT,OTHER FEES");
		return this;
	}
	
	public DcrReport ddlCashBookType() {
		System.out.println("Select ddlCashBookType - ONLINE");
		Select ddl = new Select(ddlCashBookType);
		ddl.selectByVisibleText("ONLINE");
		return this;
	}
	
	public DcrReport DateFrom() {
		System.out.println("Enter on DateFrom - 01/01/2022");
		DateFrom.clear();
		sendKeys(DateFrom,"01/01/2022");
		//sendKeys(DateFrom,"31/08/2023");
		return this;
	}
	
	public DcrReport DateTo() {
		System.out.println("Enter on DateTo - 24/07/2022");
		DateTo.clear();
		sendKeys(DateTo,"24/07/2022");
		//sendKeys(DateTo,"03/09/2023");
		return this;
	}
	
	public DcrReport btnReport() {
		System.out.println("Click on Report Button");
		click(btnReport);
		return this;
	}
	
	public boolean verifyPDFContent(String strURL, String text)
	{
		System.out.println("Pdf Reader");
		String output ="";
		boolean flag = false;
		try {
			URL url = new URL(strURL);
			BufferedInputStream file = new BufferedInputStream(url.openStream());
			PDDocument document = null;
			try {
				document = PDDocument.load(file);
				output = new PDFTextStripper().getText(document);
				System.out.println(output);
			} finally {
				if (document != null) {
					document.close();
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		if(output.contains(text)) {
			flag = true;
		}
		return flag;
	}
}