package com.qa.pages.syty_registeration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.BaseClass;

public class FeeTypeChange extends BaseClass {

	public FeeTypeChange(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy (id = "userInput") private WebElement Input;
	
	
	public FeeTypeChange Input(String name) throws IOException {
		System.out.println("Enter Input Name");
		sendKeys(Input, name);
		return this;
	}

	public FeeTypeChange enterInputName() throws IOException {
		System.out.println("Enter Input Name");
        File file = new File(".\\src\\test\\resources\\excel\\testdata11.xlsx");
        FileInputStream inputStream = new FileInputStream(file);  
        try (Workbook workbook = new XSSFWorkbook(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();        // Find number of rows in excel file
            System.out.println(rowCount);
            for (int i = 0; i <=10 ; i++) {
            Row row = sheet.getRow(i);
		sendKeys(Input, row.getCell(0).getStringCellValue());
            }
        }
		return this;
	}
}
