package com.qa.pages.StudentPortal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.BaseClass;

public class PhotoAndSign extends BaseClass {
	
	public PhotoAndSign(WebDriver rdriver) 
	{
		driver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (xpath = "//*[@id=\"myTab\"]/li[4]/a/span/i") private WebElement PhotoAndSignUrl; 	
	@FindBy (id = "btnSubmit") private WebElement btnSubmit;
	
	public PhotoAndSign PhotoAndSignUrl() {
		System.out.println("click on PhotoAndSignUrl");
		click(PhotoAndSignUrl);
		return this;
	}
	
	public PhotoAndSign btnCropPhotoSelectFile() {
		System.out.println("click on btnCropPhotoSelectFile");
		driver.findElement(By.id("file_p")).sendKeys("D:\\OfficeTesting\\Automation\\AutomationOnEclipseGit\\testing_automation\\TestingDocuments\\Studentphoto_A.jpg");
		return this;
	}
	
	public PhotoAndSign btnCropSignSelectFile() {
		System.out.println("click on btnCropSignSelectFile");
		driver.findElement(By.id("file_s")).sendKeys("D:\\OfficeTesting\\Automation\\AutomationOnEclipseGit\\testing_automation\\TestingDocuments\\Signature.png");
		return this;
	}
	
	public PhotoAndSign btnSubmit() {
		System.out.println("click on btnSubmit");
		click(btnSubmit);
		return this;
	}
}
