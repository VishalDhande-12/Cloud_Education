package com.qa.pages.payroll;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class EmployeePaySlipReport extends BaseClass{
	
	public EmployeePaySlipReport(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (id = "ddlMonthYear") private WebElement MonthORYear;
	@FindBy (id = "ddlStaff") private WebElement ddlStaff;
	@FindBy (id = "ddlEmployee") private WebElement ddlEmployee;
	@FindBy (id = "rdoAllEmployee") private WebElement rdoAllEmployee;
	@FindBy (id = "txtReason") private WebElement Reason;
	@FindBy (id = "btnShowSlipwithSuppli") private WebElement btnShow;

	public EmployeePaySlipReport ddlMonthYear() {
		System.out.println("Select MonthORYear - Oct2022");
		Select ddl = new Select(MonthORYear);
		ddl.selectByValue("Oct2022");
		return this;
	}
	
	public EmployeePaySlipReport ddlStaff() {
		System.out.println("Select ddlStaff - 1780");
		Select ddl = new Select(ddlStaff);
		ddl.selectByValue("1780");
		return this;
	}
	
	public EmployeePaySlipReport ddlEmployee() {
		System.out.println("Select ddlEmployee - 1167");
		Select ddl = new Select(ddlEmployee);
		ddl.selectByValue("1167");
		return this;
	}
	
	public EmployeePaySlipReport rdoAllEmployee() {
		System.out.println("Select rdoAllEmployee");
		click(rdoAllEmployee);
		return this;
	}
	
	public EmployeePaySlipReport Reason() {
		System.out.println("Select Reason - Full Attendance");
		sendKeys(Reason,"Full Attendance");
		return this;
	}
	
	public EmployeePaySlipReport btnShow() {
		System.out.println("Click btnShow");
		click(btnShow);
		return this;
	}
}