package com.qa.pages.StudentsCertificates;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class StudentIDCardFrontPrint extends BaseClass{
	
	public StudentIDCardFrontPrint(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}


	@FindBy (id = "ddlSession") private WebElement ddlSession;
	@FindBy (id = "ddlCourse") private WebElement ddlCourse;
	@FindBy (id = "ddlSearchBy") private WebElement ddlSearchBy;
	@FindBy (id = "userInput") private WebElement userInput;
	@FindBy (id = "ui-id-202") private WebElement userInputName;
	@FindBy(xpath = "//li[contains(@class, 'ui-menu-item')]")private List<WebElement> studentlist;
	@FindBy (id = "btnFront") private WebElement btnFront;
	@FindBy (id = "btnBack") private WebElement btnBack;
	
	
	public StudentIDCardFrontPrint openddlSession() {
		System.out.println("Select ddlSession - SESSION 2022-2023");
		Select ddl = new Select(ddlSession);
		ddl.selectByVisibleText("SESSION 2022-2023");
		return this;
	}

	public StudentIDCardFrontPrint ddlCourse() {
		System.out.println("Select ddlCourse -> BCOM - 1");
		Select ddl = new Select(ddlCourse);
		ddl.selectByVisibleText("BCOM - 1");
		return this;
	}
	
	public StudentIDCardFrontPrint ddlSearchBy() {
		System.out.println("Select ddlSearchBy");
		Select ddl = new Select(ddlSearchBy);
		ddl.selectByVisibleText("Student Name");
		scrollIntoView(ddlSearchBy, 0, 300);
		return this;
	}
	
	public StudentIDCardFrontPrint userInput() {
		System.out.println("Enter userInput ___");
		sendKeys(userInput,"KAWALE");
		for (int i=0; i < studentlist.size(); i++) {
			if (studentlist.get(i).getText().equalsIgnoreCase("KAWALE TUSHAR A --> 3715497")){
			//if (studentlist.get(i).getText().equalsIgnoreCase("Stud_3715190 KAWALE D --> 3715190")){
				studentlist.get(i).click();
				break;
			}
		}
//		Select ddl = new Select(userInputName);
//		ddl.selectByVisibleText("KAWALE TUSHAR A");
		//click(userInputName);
		return this;
	}
	
	public StudentIDCardFrontPrint btnFront() {
		System.out.println("Click btnFront");
		click(btnFront);
		return this;
	}
	
	public StudentIDCardFrontPrint btnBack() {
		System.out.println("Click btnBack");
		click(btnBack);
		return this;
	}
	
}