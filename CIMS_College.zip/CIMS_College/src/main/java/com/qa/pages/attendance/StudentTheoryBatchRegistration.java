package com.qa.pages.attendance;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class StudentTheoryBatchRegistration extends BaseClass
{
	
	public StudentTheoryBatchRegistration(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	
	//@FindBy (id = "ddlTeacher") private WebElement selectteacher;
	@FindBy (className = "checkbox") private WebElement selectteacher;
	
	@FindBy (className = "multiselect-selected-text") private WebElement clickteacher;
	//@FindBy (xpath = "/html/body/div[3]/aside[2]/section/div/div/div[2]/div[2]/div[2]/div/div[1]/div[1]/div[8]/div[2]/div/button") private WebElement clickteacher;
	
	@FindBy (id = "ddlSubject") private WebElement selectsubject;
	@FindBy (linkText = "Theory Batch Student Registration") private WebElement theorybatchstudentregistration;

	
	public StudentTheoryBatchRegistration SelectTeacher()
	{
		System.out.println("select teacher");
		click(clickteacher);
		click(selectteacher);
		//Select ddl = new Select(selectteacher);
		//ddl.selectByVisibleText("QUALITY ASSURANCE");		
		return this;
	}// AttendanceSubjectTeacherAllottmentPages end
	
	public StudentTheoryBatchRegistration SelectSubject() 
	{
		System.out.println("Select Theory Subject -> HINDI--HINDI(1.00)");
		Select ddl = new Select(selectsubject);
		ddl.selectByVisibleText("HINDI--HINDI(1.00)");
		return this;
	}//SelectSubject end

	public StudentTheoryBatchRegistration OpentheoryBatchStudentRegistration()
	{
		System.out.println("Open Theory batch student registration");
		click(theorybatchstudentregistration);
		return this;
	}// opentheoryBatchStudentRegistration end


   
}// AttendanceStudentAttendancePages class end