package com.qa.pages.establishment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class LeaveAllotmentReport extends BaseClass{
	
	public LeaveAllotmentReport(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy (id = "ddlStaff") private WebElement ddlStaff;
	@FindBy (id = "ddlDepartment") private WebElement ddlDepartment;
	@FindBy (id = "ddlDesignature") private WebElement ddlDesignature;
	@FindBy (id = "ddlPeriod") private WebElement ddlPeriod;
	@FindBy (id = "ddlLeave") private WebElement ddlLeave;
	@FindBy (id = "btnReport") private WebElement btnReport;

	
	public LeaveAllotmentReport ddlStaff() {
		System.out.println("Select ddlStaff -> VACATIONAL");
		Select ddl = new Select(ddlStaff);
		ddl.selectByVisibleText("VACATIONAL");
		return this;
	}
	public LeaveAllotmentReport ddlDepartment() {
		System.out.println("Select ddlDepartment - INFORMATION TECHNOLOGY");
		Select ddl = new Select(ddlDepartment);
		ddl.selectByVisibleText("INFORMATION TECHNOLOGY");
		return this;
	}
	
	public LeaveAllotmentReport ddlDesignature() {
		System.out.println("Select ddlDesignature - PERMANENT");
		Select ddl = new Select(ddlDesignature);
		ddl.selectByVisibleText("PERMANENT");
		return this;
	}
	
	public LeaveAllotmentReport ddlPeriod() {
		System.out.println("Select ddlPeriod - YEARLY");
		Select ddl = new Select(ddlPeriod);
		ddl.selectByVisibleText("YEARLY");
		return this;
	}
	
	public LeaveAllotmentReport ddlLeave() {
		System.out.println("Select ddlLeave -> CASUAL LEAVE-PERMANENT");
		Select ddl = new Select(ddlLeave);
		ddl.selectByVisibleText("CASUAL LEAVE-PERMANENT");
		return this;
	}
	
	public LeaveAllotmentReport btnReport() {
		System.out.println("Select btnReport");
		click(btnReport);
		return this;
	}
}