package com.qa.pages.itle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class AppearDescriptiveCIMS extends BaseClass{
	
	public AppearDescriptiveCIMS(WebDriver rdriver) {
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	
	@FindBy (id = "Itle_Student_Layout") private WebElement openitle;
	@FindBy (linkText = "My Test") private WebElement selectmytest;
	@FindBy (linkText = "My Test") private WebElement openmytest;
//	@FindBy (id = "ddlSession") private WebElement session;
	@FindBy (linkText = "BSC SEM 1 - 1 - ENGLISH - ENGLISH (TH) - 1.00") private WebElement Englishsubject;
	@FindBy (linkText = "My Test") private WebElement mytest;
    @FindBy (id = "btnStart") private WebElement starttest;
    @FindBy (id = "btnStartTest") private WebElement readytobegin;
    @FindBy (xpath = "/html/body") private WebElement clickok;
    
    @FindBy (id = "rbMoption1") private WebElement txtBoxAns1;  
    
    
  //  @FindBy (xpath = "/html/body/p") private WebElement answerone;
   // @FindBy (xpath = "/html/body/p") private WebElement answertwo;
    @FindBy (id = "btnSaveNext") private WebElement saveandnextbuttonclick;
    @FindBy (id = "btnMarkForReview") private WebElement reviewandsubmitclick;
    @FindBy (id = "btnFinalSubmit") private WebElement finishclick;
    @FindBy (id = "btnOK") private WebElement okclick;
	
	
    public AppearDescriptiveCIMS openITLE() {
		System.out.println("Select ITLE");
		click(openitle);
		return this;
	}
    public AppearDescriptiveCIMS selectMyTest() {
		System.out.println("Select ITLE");
		click(selectmytest);
		return this;
	}
	public AppearDescriptiveCIMS selectSubject() {
		System.out.println("BSC SEM 1 - 1 - ENGLISH - ENGLISH (TH) - 1.00");
		click(Englishsubject);
		return this;
	}
	public AppearDescriptiveCIMS openMyTest() {
		System.out.println("Open My Test");
		click(openmytest);
		return this;
	}
	public AppearDescriptiveCIMS openStartTest() {
		System.out.println("Start Test");
		click(starttest);
		return this;
	}
	public AppearDescriptiveCIMS openReadyToBegin() {
		System.out.println("Ready to Begin");
		click(readytobegin);
		return this;
	}
	public AppearDescriptiveCIMS clickOnTxtAnsOne() throws Exception {
		System.out.println("Answear One");
		//scrollToElement(txtBoxAns1);
		Thread.sleep(2000);
		//click(txtBoxAns1);
		driver.findElement(By.xpath("//*[@id=\"rbMoption1\"]")).click();
		//sendKeys(txtBoxAns1,"Model�view�controller is a software architectural pattern");
		//sendKeys(txtBoxAns1,"A) h");
		return this;
	}
		public AppearDescriptiveCIMS clickOnSaveAndNext() {
			System.out.println("Click on Save and Next");
			scrollIntoView(saveandnextbuttonclick, 0, 500);
			click(saveandnextbuttonclick);
			return this;
		}
		
		
//		public AppearDescriptiveCIMS clickOnAnswerTwo() {
//			System.out.println("write answear two: ");
//			click(answertwo);
//			sendKeys(answertwo, "second answear  ");
//			return this;
//		} 
		public AppearDescriptiveCIMS clickOnReviewAndSubmitButton() {
			System.out.println("Click on Final Submit");
			click(reviewandsubmitclick);
			return this;
		}
		public AppearDescriptiveCIMS clickOnFinishButton() {
			System.out.println("Click on Finish Button");
			click(finishclick);
			return this;
		}
		public AppearDescriptiveCIMS clickOnOkButton() {
			System.out.println("Click on Finish Button");
			click(okclick);
			return this;
		}

		
		
	

	
	/*public AppearDescriptive clickOnStartTest() {
		System.out.println("Click on 'Start Test'");
		click(startDescriptiveTest);
		return this;
	}   
	public AppearDescriptive clickOnReadyToBegin() {
		System.out.println("Click on 'I am Ready To Begin Test'");
		click(iAmReadyToBegin);
		return this;
	}
	public AppearDescriptive clickOnTxtAnsOne() {
		System.out.println("answear one");
		scrollToElement(txtBoxAns1);
		sendKeys(txtBoxAns1,"Model�view�controller is a software architectural pattern");
		return this;
	}
	public AppearDescriptive clickOnSaveAndNext() {
		System.out.println("Click on Save and Next");
		scrollIntoView(saveandnextbuttonclick, 0, 500);
		click(saveandnextbuttonclick);
		return this;
	}
	public AppearDescriptive clickOnTxtAnsTwo() {
		System.out.println("answear Two");
		scrollToElement(txtBoxAns2);
		sendKeys(txtBoxAns2,"set of certain stages which occur at a certain time");
		return this;
	}
	public AppearDescriptive clickOnSaveAndNextButton() {
		System.out.println("Click on Save and Next");
		scrollIntoView(saveandnextbuttonclick, 0, 500);
		click(saveandnextclick);
		return this;
	}
	public AppearDescriptive clickOnReviewAndSubmitButton() {
		System.out.println("Click on Final Submit");
		click(reviewandsubmitclick);
		return this;
	}
	public AppearDescriptive clickOnFinishButton() {
		System.out.println("Click on Finish Button");
		click(finishclick);
		return this;
	}
	public AppearDescriptive clickOnOkButton() {
		System.out.println("Click on Finish Button");
		click(okclick);
		return this;
	}
	public AppearDescriptive clickOnCloseWindow() {
		System.out.println("Click on Finish Button");
		click(windowcloseclick);
		return this;
	}*/
	/*public MyDescriptivepage clickOnAnswerOne()
	{
		System.out.println("Click on 'Answer one'");
		click(answerone);
		System.out.println("Clicked......................'");
		return this;
	}
 public MyDescriptivepage clickOnAnswertwo()
	{
		System.out.println("Click on 'Answer two'");
		click(answertwo);
		System.out.println("Clicked......................'");
		return this;
	}*/
	
	


	
	
	
	
//	public MyTest clickOnAlertClose() {
//		System.out.println("Click on 'Close'");
//		click(finalclose);
//		return this;
//	}
	
}