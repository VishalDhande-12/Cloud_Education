package com.qa.pages.itle;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class Create_Objective_test_CIMS_Link extends BaseClass {

	public Create_Objective_test_CIMS_Link(WebDriver rdriver) {
		driver = rdriver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(linkText = "Course/Subject")
	private WebElement courcesubject;
	@FindBy(linkText = "Select Course/Subject")
	private WebElement selectcoursesubject;
	@FindBy(xpath = "/html/body/div[3]/aside[1]/section/ul/li[5]/ul/li/ul/li/a/span")
	private WebElement selectcoursesubject1;

	@FindBy(id = "ddlSession")
	private WebElement selectsession;
	@FindBy(id = "ddlCourse")
	private WebElement selectcourse;
	@FindBy(linkText = "BSC SEM 1 - 1 - ENGLISH - ENGLISH (TH) - 1.00")
	private WebElement Englishsubject;
	@FindBy(linkText = "Test")
	private WebElement test;

	@FindBy(id = "btnAddTest")
	private WebElement createtest;// .....
	@FindBy(id = "txtSyllabus")
	private WebElement testtitle;
	@FindBy(id = "ddlTestType")
	private WebElement testscheduletype;
	@FindBy(id = "txtStartDate")
	private WebElement teststartdate;
	@FindBy(id = "txtEndDate")
	private WebElement testEndDate;

	// @FindBy(id = "lj") private List<testEndDateA> testEndDateA;

	@FindBy(css = "td.day.today.active")
	private WebElement selecttodayactivedate;
	@FindBy(id = "txtTestDuration")
	private WebElement testduration;
	@FindBy(id = "txtTimeStar")
	private WebElement teststarttime;// start time
	@FindBy(xpath = "//div[@id='DivDashboard']/div/div")
	private WebElement selectstarttime;
	@FindBy(id = "ddlQuestionType")
	private WebElement typeofquestion;

	@FindBy(id = "lblAddQuestions")
	private WebElement setquestionpaper;
	@FindBy(id = "txtNoSet")
	private WebElement noofpapersets;
	@FindBy(id = "txtEasyUser")
	private WebElement easy;
	@FindBy(id = "txtDifficultyLevel")
	private WebElement objectivemarkperstudent;
	@FindBy(id = "btnOKModal")
	private WebElement submitbutton;
	@FindBy(id = "lblAddStudent")
	private WebElement assignexamtostudent;
	@FindBy(id = "IsAllStd")
	private WebElement assignexamcheckbox;
	@FindBy(id = "btnCount")
	private WebElement okbutton;
	@FindBy(id = "IsAfterResult")
	private WebElement afterresulton;// new test

	@FindBy(id = "btnSave")
	private WebElement savebutton;

	public Create_Objective_test_CIMS_Link openCourceSubject() // it will click on Course/Subject first
	{
		System.out.println("Open Course/Subject");
		click(courcesubject);
		return this;
	}

	public Create_Objective_test_CIMS_Link openSelectCourseSubject() // it will click on Select Course subject first
	{
		System.out.println("Click on Select Course");
		click(selectcoursesubject);
		return this;
	}

	public Create_Objective_test_CIMS_Link openSelectCourseSubject1() // it will click on Select Course subject first
	{
		System.out.println("Click on Select Course1");
		click(selectcoursesubject1);
		return this;
	}

	public Create_Objective_test_CIMS_Link select_ITLE_Session() {
		System.out.println("Select ITLE Session 'ITLE 2022-2023'");
		Select ddl = new Select(selectsession);
		ddl.selectByVisibleText("ITLE 2022-2023");
		return this;
	}

	public Create_Objective_test_CIMS_Link select_Course() {
		System.out.println("Select ITLE Course 'BSC SEM 1 - 1'");
		Select ddl = new Select(selectcourse);
		ddl.selectByVisibleText("BSC SEM 1 - 1");
		return this;
	}

//	public Create_Objective_test_CIMS_Link selectCourseSubject() {
//		System.out.println("Select Course");
//        Select ddl = new Select(Englishsubject);
//       ddl.selectByVisibleText("BSC SEM 1 - 1 - ENGLISH - ENGLISH (BS) - 0.00");
//        return this;
//	}

	public Create_Objective_test_CIMS_Link openEnglishSubject() // it will click on English/Subject first
	{
		// System.out.println("BSC SEM 1 - 1 - ENGLISH - ENGLISH (BS) - 0.00");
		System.out.println("BSC SEM 1 - 1 - ENGLISH - ENGLISH (TH) - 1.00");
		click(Englishsubject);
		return this;
	}

	public Create_Objective_test_CIMS_Link Test() // it will click on Test first
	{
		System.out.println("Open Test");
		click(test);
		return this;
	}

	public Create_Objective_test_CIMS_Link createTest() // it will click on Test first
	{
		System.out.println("Create Test");
		click(createtest);
		return this;
	}

	public Create_Objective_test_CIMS_Link enterTestTitle() {
		System.out.println("Enter Test Title - Test0");
		sendKeys(testtitle, "Test154");
		return this;
	}

	public Create_Objective_test_CIMS_Link testScheduleType() {
		System.out.println("Select Schedule Type - 'Non-Flexible'");
		Select ddl = new Select(testscheduletype);
		ddl.selectByVisibleText("Non-Flexible");
		return this;
	}

	public Create_Objective_test_CIMS_Link selectTestStartDate() {
		System.out.println("Select Test Start Date - TodayDate");
		click(teststartdate);
		click(selecttodayactivedate);
		return this;
	}

	public Create_Objective_test_CIMS_Link selectTest_End_Date() {
		System.out.println("Select Test End Date");
		// click(testEndDate);
		sendKeys(testEndDate, "02/03/2024");
		// sendKeys(teststartdate, null)
		LocalDate today = LocalDate.now();
		LocalDate tomorrow = today.plusDays(1);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String tomorrowDateStr = tomorrow.format(formatter);

		return this;
	}

	public Create_Objective_test_CIMS_Link enterTestDuration() {
		System.out.println("Enter Test Duration - 00:10");
		sendKeys(testduration, "00:10");
		return this;
	}

	public Create_Objective_test_CIMS_Link selectStartTime() throws Exception {
		System.out.println("Enter Current Time -" + GetCurrentTime());
		sendKeys(teststarttime, GetCurrentTime());
		Thread.sleep(2000);
		teststarttime.sendKeys(Keys.SPACE, Keys.ENTER);
		Thread.sleep(2000);
		return this;
	}

	public Create_Objective_test_CIMS_Link selectQuestionType() {
		System.out.println("Select Question Type - Objective");
		Select ddl = new Select(typeofquestion);
		ddl.selectByVisibleText("Objective");
		return this;
	}

	public Create_Objective_test_CIMS_Link SetQuestionPaper() // it will click on Set Question paper
	{
		System.out.println("Creat eTest");
		click(setquestionpaper);
		return this;
	}

	public Create_Objective_test_CIMS_Link EnterNoOfPaperSets() {
		System.out.println("Enter Paper Set - 1");
		sendKeys(noofpapersets, "1");
		return this;
	}

	public Create_Objective_test_CIMS_Link EnterEasyQuestion() {
		System.out.println("Enter Easy Question Set - 1");
		sendKeys(easy, "1");
		return this;
	}

	public Create_Objective_test_CIMS_Link EnterObjectiveMarkPerStudent() {
		System.out.println("Enter Marks Per Student - 1");
		sendKeys(objectivemarkperstudent, "1");
		return this;
	}

	public Create_Objective_test_CIMS_Link clickOnSubmitButton() {
		System.out.println("Click On Submit Button");
		click(submitbutton);
		;
		return this;
	}

	public Create_Objective_test_CIMS_Link OpenAssignExam() // it will click on Course/Subject first
	{
		System.out.println("Open Course/Subject");
		click(assignexamtostudent);
		return this;
	}

	public Create_Objective_test_CIMS_Link AssignExamCheckBox() // it will check box
	{
		System.out.println("click sellect all check box");

		if (assignexamcheckbox.isSelected()) {

			System.out.println("Checkbox is checked");
		} else {
			System.out.println("Checkbox is not checked");
			click(assignexamcheckbox);

		}

		return this;
	}

	public Create_Objective_test_CIMS_Link clickOnOkButton() {
		System.out.println("Click On Ok Button");
		scrollIntoView(okbutton, 0, 500);
		click(okbutton);
		return this;
	}

	public Create_Objective_test_CIMS_Link clickOnAfterResultOn()// new function
	{
		System.out.println("Click On AfterResultOn");
		click(afterresulton);
		;
		return this;
	}

	public Create_Objective_test_CIMS_Link clickOnSaveButton() {
		System.out.println("Click On Save Button");
		click(savebutton);
		;
		return this;
	}

	public Create_Objective_test_CIMS_Link getAllertText() {
		getAllertText();
		return this;
	}
}
