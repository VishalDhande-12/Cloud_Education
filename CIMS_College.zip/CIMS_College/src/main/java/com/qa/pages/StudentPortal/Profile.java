package com.qa.pages.StudentPortal;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class Profile extends BaseClass {
	
	public Profile(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (id = "ddlGender") private WebElement ddlGender;
	@FindBy (id = "txtmobileNo") private WebElement mobileNo;
	@FindBy (id = "ddlCasteCategory") private WebElement ddlCasteCategory;
	@FindBy (id = "ddlNationality") private WebElement ddlNationality;
	@FindBy (id = "txtdob") private WebElement dob;
	@FindBy (id = "ddlReligion") private WebElement ddlReligion;
	@FindBy (id = "txtAdharNo") private WebElement AdharNo;
	@FindBy (id = "ddlOccupation") private WebElement ddlOccupation;
	@FindBy (id = "btnSubmitPersonal") private WebElement btnSubmitPersonal;
	
	
	public Profile ddlGender() {
		System.out.println("Select ddlGender - MALE");
		Select ddl = new Select(ddlGender);
		ddl.selectByVisibleText("MALE");
		return this;
	}
	
	public Profile mobileNo() {
		System.out.println("Select mobileNo - 8149914475");
		sendKeys(mobileNo,"8149914475");
		return this;
	}
	
	public Profile ddlCasteCategory() {
		System.out.println("Select ddlCasteCategory - OBC");
		Select ddl = new Select(ddlCasteCategory);
		ddl.selectByVisibleText("OBC");
		return this;
	}
	
	public Profile ddlNationality() {
		System.out.println("Select ddlNationality - INDIAN");
		Select ddl = new Select(ddlNationality);
		ddl.selectByVisibleText("INDIAN");
		return this;
	}
	
	public Profile dob() {
		System.out.println("Select dob - 12/08/2000");
		sendKeys(dob,"12/08/2000");
		return this;
	}
	
	public Profile ddlReligion() {
		System.out.println("Select ddlReligion - HINDU");
		Select ddl = new Select(ddlReligion);
		ddl.selectByVisibleText("HINDU");
		return this;
	}
	
	public Profile AdharNo() {
		System.out.println("Select AdharNo - 123456789012");
		sendKeys(AdharNo,"123456789012");
		return this;
	}
	
	public Profile ddlOccupation() {
		System.out.println("Select ddlOccupation - ENGINEER");
		Select ddl = new Select(ddlOccupation);
		ddl.selectByVisibleText("ENGINEER");
		return this;
	}
	
	public Profile btnSubmitPersonal() {
		System.out.println("Click btnSubmitPersonal");
		click(btnSubmitPersonal);
		return this;
	}
}
