package com.qa.pages.StudentsCertificates;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class StudentIDCardBackPrint extends BaseClass{
	
	public StudentIDCardBackPrint(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}


	@FindBy (id = "ddlSession") private WebElement ddlSession;
	@FindBy (id = "ddlCourse") private WebElement ddlCourse;
	@FindBy (id = "ddlSearchBy") private WebElement ddlSearchBy;
	@FindBy (id = "userInput") private WebElement userInput;
	@FindBy (id = "ui-id-202") private WebElement userInputName;
	
	@FindBy(xpath = "//li[contains(@class, 'ui-menu-item')]")private List<WebElement> studentlist;
	//@FindBy(xpath = "(.//*[normalize-space(text()) and normalize-space(.)='Enter Input'])[1]/following::input[1]")private List<WebElement> studentlist;
	//@FindBy (id = "ui-id-5") private WebElement student;
	
	@FindBy (id = "btnFront") private WebElement btnFront;
	@FindBy (id = "btnBack") private WebElement btnBack;
	
	
	public StudentIDCardBackPrint openddlSession() {
		System.out.println("Select ddlSession -> SESSION 2022-2023");
		Select ddl = new Select(ddlSession);
		ddl.selectByVisibleText("SESSION 2022-2023");
		return this;
	}

	public StudentIDCardBackPrint ddlCourse() {
		System.out.println("Select ddlCourse -> BCOM - 1");
		Select ddl = new Select(ddlCourse);
		ddl.selectByVisibleText("BCOM - 1");
		return this;
	}
	
	public StudentIDCardBackPrint ddlSearchBy() {
		System.out.println("Select ddlSearchBy");
		Select ddl = new Select(ddlSearchBy);
		ddl.selectByVisibleText("Student Name");
		scrollIntoView(ddlSearchBy, 0, 300);
		return this;
	}
	
	public StudentIDCardBackPrint userInput() throws InterruptedException {
		System.out.println("Enter userInput");
		sendKeys(userInput,"KAWALE");
		//click(student);
		for (int i=0; i < studentlist.size(); i++) {
			if (studentlist.get(i).getText().equalsIgnoreCase("KAWALE TUSHAR A --> 3715497")){
			//if (studentlist.get(i).getText().equalsIgnoreCase("STUD_3760293 TRUPTI  --> 3760293")){
				Thread.sleep(1000);
				studentlist.get(i).click();
				break;
			}
		}
		return this;
	}
	
	public StudentIDCardBackPrint btnFront() {
		System.out.println("Click btnFront");
		click(btnFront);
		return this;
	}
	
	public StudentIDCardBackPrint btnBack() {
		System.out.println("Click btnBack");
		click(btnBack);
		return this;
	}
	
}