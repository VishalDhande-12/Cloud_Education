package com.qa.pages.StudentsCertificates;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.BaseClass;

public class StudentsAcademicUrls extends BaseClass{
	
	public StudentsAcademicUrls(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (linkText = "ACADEMIC") private WebElement ACADEMIC;
	@FindBy (linkText = "Student Reports") private WebElement StudentReports;
	@FindBy (linkText = "Certificate") private WebElement Certificate;
	@FindBy (linkText = "Student Tc") private WebElement StudentTc;
	@FindBy (linkText = "Student ID Card") private WebElement StudentIDCard;

	
	public StudentsAcademicUrls openACADEMIC() {
		System.out.println("Open ACADEMIC");
		click(ACADEMIC);
		return this;
	}
	
	public StudentsAcademicUrls openStudentReports() {
		System.out.println("Open StudentReports");
		click(StudentReports);
		return this;
	}
	
	public StudentsAcademicUrls openCertificate() {
		System.out.println("Open Certificate");
		click(Certificate);
		return this;
	}
	
	public StudentsAcademicUrls openStudentTc() {
		System.out.println("Open StudentTc");
		click(StudentTc);
		return this;
	}
	
	public StudentsAcademicUrls openStudentIDCard() {
		System.out.println("Open StudentIDCardFrontPrint");
		click(StudentIDCard);
		return this;
	}


}