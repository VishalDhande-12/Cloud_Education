package com.qa.pages.attendance;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.BaseClass;

public class ClasswiseTimetableReport extends BaseClass
{

	public ClasswiseTimetableReport(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (xpath = "/html/body/div[3]/aside[1]/section/div/ul/li[6]/ul/li[2]/a/span") private WebElement timetablereport;
	@FindBy (xpath = "/html/body/div[3]/aside[1]/section/div/ul/li[6]/ul/li[2]/ul/li[1]/a/span") private WebElement classwisetimetablereport;
	@FindBy (id = "btnReport") private WebElement clickformat1;
	@FindBy (id = "btnReportFormat") private WebElement clickformat2;
	@FindBy (id = "btnCancel") private WebElement clickcancel;
	//@FindBy (xpath = "") private WebElement ;
	
	public ClasswiseTimetableReport OpenTimeTableReport()
	{
		System.out.println("Open TimeTable Report");
		click(timetablereport);
		return this;
	}// OpenTimeTableReport end

	public ClasswiseTimetableReport OpenClasswiseTimeTableReport()
	{
		System.out.println("Open ClasswiseTimeTable Report");
		click(classwisetimetablereport);
		return this;
	}// OpenClasswiseTimeTableReport end
	
	public ClasswiseTimetableReport ClickFormat1()
	{
		System.out.println("click on format1 button");
		click(clickformat1);
		return this;
	}// ClickFormat1 end
	
	public ClasswiseTimetableReport ClickFormat2()
	{
		System.out.println("click on format2 button");
		click(clickformat2);
		return this;
	}// ClickFormat2 end

}// AttendanceTimetableCreationPages class end