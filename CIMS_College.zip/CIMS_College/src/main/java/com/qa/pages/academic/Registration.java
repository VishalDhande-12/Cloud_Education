package com.qa.pages.academic;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class Registration extends BaseClass{
	
	public Registration(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	
	//Student Details
	@FindBy (id = "ddlCourse") private WebElement course;
	@FindBy (id = "NAME") private WebElement search;
	@FindBy (id = "userInput") private WebElement studentname;
	@FindBy (id = "ddlTitle") private WebElement title;
	@FindBy (id = "txtlastName") private WebElement lastName;
	@FindBy (id = "txtFirstName") private WebElement firstName;
	@FindBy (id = "txtMiddleName") private WebElement middleName;
	@FindBy (id = "ddlGender") private WebElement gender;
	@FindBy (id = "ddlCasteCategory") private WebElement caste;
	
	@FindBy (id = "txtMotherName") private WebElement mothersname;
	@FindBy (id = "txtFatherName") private WebElement fathersname;
	@FindBy (id = "txtFormNo") private WebElement formnumber;
	@FindBy (id = "txtProvisionlAdmNo") private WebElement admNo;
	@FindBy (id = "txtAddress") private WebElement address;
	@FindBy (id = "txtEmailId") private WebElement email;
	@FindBy (id = "txtMobile") private WebElement studentmobile;
	@FindBy (id = "txtDOB") private WebElement DOB;
	@FindBy (id = "txtParentMobile") private WebElement parentmobile;

	//Payment
	@FindBy (id = "txtAmount") private WebElement amt;
	@FindBy (id = "ddlPaymentMode") private WebElement pamentmode;
	@FindBy (id = "remark") private WebElement remark;	
	
	@FindBy (id = "btnSubmit") private WebElement submit;	
	
	@FindBy (id = "alerts") private WebElement confirmationmessage;


	
	
	
	public Registration selectCourse() {
		Select ddl = new Select(course);
		ddl.selectByVisibleText("BSC SEM 1 - 1");
		System.out.println("Course Selected -> BSC SEM 1 - 1");
		return this;
	}
	
	
	public Registration selectSearchCriteria() {
		click(studentname);
		System.out.println("Selected Student Name");
		return this;
	}
	
	
	public Registration selectTitle() {
		Select ddl = new Select(title);
		ddl.selectByVisibleText("MR.");
		System.out.println("Selected Title - MR.");
		return this;
	}
	
	
	public Registration enterLastName() throws IOException {
        File file = new File(".\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream inputStream = new FileInputStream(file);  
        try (Workbook workbook = new XSSFWorkbook(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();        // Find number of rows in excel file
            System.out.println(rowCount);
            for (int i = 1; i <=1 ; i++) {
            Row row = sheet.getRow(i);
		sendKeys(lastName, row.getCell(2).getStringCellValue());
		System.out.println("Entered Last Name");
            }
        }
		return this;
	}
	


	public Registration enterFirstName() throws IOException {
	    File file = new File(".\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream inputStream = new FileInputStream(file);  
        try (Workbook workbook = new XSSFWorkbook(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();        // Find number of rows in excel file
            System.out.println(rowCount);
            for (int i = 1; i <=1 ; i++) {
            Row row = sheet.getRow(i);
		sendKeys(firstName, row.getCell(0).getStringCellValue());
		System.out.println("Enter First Name");
            }
        }
		return this;
	}


	public Registration enterMiddleName() throws IOException {
		   File file = new File(".\\src\\test\\resources\\excel\\testdata.xlsx");
	        FileInputStream inputStream = new FileInputStream(file);  
	        try (Workbook workbook = new XSSFWorkbook(inputStream)) {
	            Sheet sheet = workbook.getSheetAt(0);
	            int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();        // Find number of rows in excel file
	            System.out.println(rowCount);
	            for (int i = 1; i <=1 ; i++) {
	            Row row = sheet.getRow(i);
			sendKeys(middleName, row.getCell(1).getStringCellValue());
			System.out.println("Entered Middle Name");
	            }
	        }
			return this;
		}

	

	public Registration selectGender() {
		Select ddl = new Select(gender);
		ddl.selectByVisibleText("MALE");
		System.out.println("Selected Gender - MALE");
		return this;
	}
	
	
	public Registration selectCasteCategory() {
		Select ddl = new Select(caste);
		ddl.selectByVisibleText("OPEN");
		System.out.println("Selected Caste Category - OPEN");
		return this;
	}
	
	
	public Registration enterMothersName() {
		sendKeys(mothersname, "Michelle");
		System.out.println("Entered Mothers Name - Michelle");
		return this;
	}
	
	
	public Registration enterFathersName() {
		sendKeys(fathersname, "Danny");
		System.out.println("Entered Fathers Name - Danny");
		return this;
	}
	
	
	public Registration enterFormNo() {
		sendKeys(formnumber, "0156");
		System.out.println("Entered Form Number - 0156");
		return this;
	}
	
	
	
	public Registration enterProvisionalADMNo() {
		sendKeys(admNo, "12345");
		System.out.println("Entered Provisional ADM No. - 12345");
		return this;
	}
	
	
	public Registration enterAddress() {
		sendKeys(address, "High Street 12, C-ring Road");
		System.out.println("Entered Address -> High Street 12, C-ring Road");
		return this;
	}
	
	
	public Registration enterEmailId() {
		sendKeys(email, "abc@xyz.com");
		System.out.println("Entered Email Id -> abc@xyz.com");
		return this;
	}
	
	
	public Registration enterStudentMobileNo() {
		sendKeys(studentmobile, "1234567890");
		System.out.println("Entered Student Mobile No. - 1234567890");
		return this;
	}
	
	
	public Registration enterDOB() {
		sendKeys(DOB,"01/01/2000");
		System.out.println("Entered DOB - 01/01/2000");
		return this;
	}
	
	
	public Registration enterParentMobileNo() {
		sendKeys(studentmobile, "1234567890");
		System.out.println("Entered Parent Mobile no - 1234567890");
		return this;
	}
	
	//PAYMENT
	public Registration enterAmount() {
		sendKeys(amt, "100");
		System.out.println("Amount Entered - 100");
		return this;
	}
	
	public Registration selectPaymentMode() {
		Select ddl = new Select(pamentmode);
		ddl.selectByVisibleText("Cash");
		System.out.println("Select Cash as Payment Mode - Cash");
		return this;
	}
	
	public Registration enterRemark() {
		sendKeys(remark, "This is Registration Process");
		System.out.println("Remark Entered - This is Registration Process");
		return this;
	}
	
	
	//Submit
	public Registration clickOnSubmit() {
		click(submit);
		System.out.println("Clicked on Submit");
		return this;
	}
	
	public String verifyConfirmationMessage() {
		String confirmationMsg = getText(confirmationmessage);
		System.out.println("Confirmation Message - " + confirmationMsg );
		return confirmationMsg;
	}
	
	
	
	
}