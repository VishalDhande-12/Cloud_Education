package com.qa.pages.StudentPortal;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class ProfileAddress  extends BaseClass{

	public ProfileAddress(WebDriver rdriver)
	{
		driver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy (xpath = "//*[@id=\"myTab\"]/li[3]/a/span/i") private WebElement AddressUrl;
	@FindBy (id = "ddlCountry") private WebElement ddlCountry;
	@FindBy (id = "ddlState") private WebElement ddlState;
	@FindBy (id = "ddlDistrict") private WebElement ddlDistrict;
	@FindBy (id = "ddlCity") private WebElement ddlCity;
	@FindBy (id = "txtParmanentAdd") private WebElement ParmanentAdd;
	@FindBy (xpath = "(.//*[normalize-space(text()) and normalize-space(.)='TEMPORARY ADDRESS'])[1]/following::label[1]") private WebElement chkSameParmanent;
	@FindBy (id = "btnSubmitAddress") private WebElement btnSubmitAddress;
	@FindBy (id = "txtCity") private WebElement txtCity;
	
	public ProfileAddress AddressUrl() {
		System.out.println("click on AddressUrl");
		click(AddressUrl);
		return this;
	}
	
	public ProfileAddress ddlCountry() {
		System.out.println("Select ddlCountry");
		Select ddl = new Select(ddlCountry);
		ddl.selectByVisibleText("INDIA");
		return this;
	}
	
	public ProfileAddress ddlState() {
		System.out.println("Select ddlState");
		Select ddl = new Select(ddlState);
		ddl.selectByVisibleText("Maharashtra");
		return this;
	}
	
	public ProfileAddress ddlDistrict() {
		System.out.println("Select ddlDistrict");
		Select ddl = new Select(ddlDistrict);
		ddl.selectByVisibleText("Nagpur");
		return this;
	}
	
	public ProfileAddress ddlCity() {
		System.out.println("Select ddlCity");
		Select ddl = new Select(ddlCity);
		ddl.selectByVisibleText("Other");
		return this;
	}
	
	public ProfileAddress txtCity() {
		System.out.println("Select txtCity");
		sendKeys(txtCity,"Nagpur");
		return this;
	}
	
	public ProfileAddress ParmanentAdd() {
		System.out.println("Select ParmanentAdd");
		clearText(ParmanentAdd);
		sendKeys(ParmanentAdd,"Civil Line");
		return this;
	}
	
	public ProfileAddress chkSameParmanent() {
		System.out.println("click chkSameParmanent");
		click(chkSameParmanent);
		return this;
	}
	
	public ProfileAddress btnSubmitAddress() {
		System.out.println("Click btnSubmitAddress");
		click(btnSubmitAddress);
		return this;
	}
}
