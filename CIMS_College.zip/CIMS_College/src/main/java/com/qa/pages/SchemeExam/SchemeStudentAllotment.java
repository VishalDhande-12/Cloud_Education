package com.qa.pages.SchemeExam;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class SchemeStudentAllotment extends BaseClass {
	
	public SchemeStudentAllotment  (WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy (id = "ddlAcdSession") private WebElement AcademicSession;
	@FindBy (id = "ddlBasicCourse") private WebElement BasicCourse;
	@FindBy (id = "ddlCourse") private WebElement Course;
	@FindBy (id = "ddlScheme") private WebElement AllottoScheme;
	@FindBy (id = "ChkAll") private WebElement checkALL;
	@FindBy (id = "btnSubmit") private WebElement Submit;
	
	
	
	public SchemeStudentAllotment AcademicSession() {		
	    System.out.println("Select AcademicSession");
		Select ddl = new Select(AcademicSession);
		ddl.selectByVisibleText("SESSION 2022-2023");
		return this;
	}		
	
	
	public SchemeStudentAllotment BasicCourse() {		
	    System.out.println("Select BasicCourse");
		Select ddl = new Select(BasicCourse);
		ddl.selectByVisibleText("BSC SEM 1");
		return this;
	}		
	
	public SchemeStudentAllotment Course() {
		System.out.println("Enter Course");		 
	    Select ddl = new Select(Course);
		ddl.selectByVisibleText("BSC SEM 1 - 1");		
		return this;
		}
	
	public SchemeStudentAllotment AllottoScheme() {
		System.out.println("Select AllottoScheme");
		Select ddl = new Select(AllottoScheme);
		ddl.selectByVisibleText("(SESSION 2022-2023)");
		return this;
		}
	
	public SchemeStudentAllotment CheckALL() {
		System.out.println("Click on checkALL");
		click(checkALL);			
		return this;
		}
	
	public SchemeStudentAllotment Submit() {
		System.out.println("Click on Submit");
		click(Submit);			
		return this;
		}
		
	public SchemeStudentAllotment SchemeStudentAllotmentactivity() throws Exception {
		AcademicSession();
		BasicCourse();
		Course();
		AllottoScheme();
		//CheckALL(); 
		
		WebElement webElement=driver.findElement(By.xpath("/html/body/div[3]/aside[2]/section/div/div/div/div[3]/div/div[3]/div/div/div/div/div[2]/div/div/div[2]/table/tbody"));
		List<WebElement> rows=webElement.findElements(By.xpath("./tr"));     
		int rowCount =rows.size();		// Find number of rows in excel file
		System.out.println(rowCount); 
		for (int i = 1;i <=4;i++) {	
		Thread.sleep(1000);	
		
		 WebElement option1 = driver.findElement(By.xpath("//table[@id='example']/tbody/tr["+i+"]/td/input"));							

	        // This will Toggle the Check box 		
	        option1.click();			

	        // Check whether the Check box is toggled on 		
	        if (option1.isSelected()) {					
	            System.out.println("Checkbox is already checked");					

	        } else {			
	            System.out.println("Checked now");
	            driver.findElement(By.xpath("//table[@id='example']/tbody/tr["+i+"]/td/input")).click();
	        }				
		
		}
		
 	     Thread.sleep(1000);
		 Submit();
		Thread.sleep(5000); 
		return this;
		}
	

	

}
