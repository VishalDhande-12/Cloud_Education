package com.qa.pages.payroll;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class AnnualPaySlipReport extends BaseClass{
	
	public AnnualPaySlipReport(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (id = "txtFromDate") private WebElement FromDate;
	@FindBy (xpath = "/html/body/div[10]/div[3]/table/tbody/tr[1]/td[6]") private WebElement day1;
	@FindBy (id = "txtToDate") private WebElement ToDate;
	@FindBy (xpath = "/html/body/div[11]/div[3]/table/tbody/tr[3]/td[1]") private WebElement day2;
	@FindBy (id = "ddlStaff") private WebElement ddlStaff;
	@FindBy (id = "ddlEmployee") private WebElement ddlEmployee;
	@FindBy (id = "ddlEmployeeName") private WebElement ddlEmployeeName;
	@FindBy (id = "btnShow") private WebElement btnShow;

	public AnnualPaySlipReport FromDate() {
		System.out.println("Select FromDate - 01/01/2022");
		sendKeys(FromDate,"01/01/2022");
		click(day1);
		return this;
	}
	
	public AnnualPaySlipReport ToDate() {
		System.out.println("Select ToDate - 08/08/2022");
		sendKeys(ToDate,"08/08/2022");
		click(day2);
		return this;
	}
	
	public AnnualPaySlipReport ddlStaff() {
		System.out.println("Select ddlStaff - 1780");
		Select ddl = new Select(ddlStaff);
		ddl.selectByValue("1780");
		return this;
	}
	
	public AnnualPaySlipReport ddlEmployee() {
		System.out.println("Select ddlEmployee - REGULAR");
		Select ddl = new Select(ddlEmployee);
		ddl.selectByVisibleText("REGULAR");
		return this;
	}
	
	public AnnualPaySlipReport ddlEmployeeName() {
		System.out.println("Select ddlEmployeeName - Ram M Dev");
		Select ddl = new Select(ddlEmployeeName);
		ddl.selectByVisibleText("Ram M Dev");
		return this;
	}
	
	public AnnualPaySlipReport btnShow() {
		System.out.println("Select btnShow");
		click(btnShow);
		return this;
	}
}