package com.qa.pages.SchemeExam;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.BaseClass;

public class ExaminationProcess extends BaseClass {
	
	public ExaminationProcess(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	//@FindBy (xpath = "/html/body/div[3]/aside[1]/section/ul/li[4]/a/span[1]") private WebElement ExaminationProcess;
	@FindBy (linkText = "Examination Process") private WebElement ExaminationProcess;
	
	
	public ExaminationProcess ExaminationProcessSubModule() {
		System.out.println("Open ExaminationProcess Submodule");
		click(ExaminationProcess);
		return this;
	}

}
