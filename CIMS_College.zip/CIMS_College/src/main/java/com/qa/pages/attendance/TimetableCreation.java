package com.qa.pages.attendance;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class TimetableCreation extends BaseClass
{

	public TimetableCreation(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (linkText = "Time Table") private WebElement opentimetable;
	@FindBy (xpath = "/html/body/div[3]/aside[1]/section/div/ul/li[5]/ul/li[2]/ul/li[1]/a/span") private WebElement opentimetablecreation;
	@FindBy (id = "ddlSubject") private WebElement subjectselection;
	@FindBy (id = "ddlDay") private WebElement dayselection;
	@FindBy (id = "ddlSlot") private WebElement slotselection;
	@FindBy (id = "ddlRoom") private WebElement roomselection;
	@FindBy (id = "chkUserId30008901") private WebElement checkBoxElement1;
	@FindBy (id = "hdnUserId30008902") private WebElement checkBoxElement2;

	
	
	
	
	
	
	public TimetableCreation OpenTimetable()
	{
		System.out.println("Open Timetable");
		click(opentimetable);
		return this;
	}// OpenTimetable end

	public TimetableCreation OpenTimetableCreation()
	{
		System.out.println("Open class Timetable");
		click(opentimetablecreation);
		return this;
	}// OpenClassTimetable end

	public TimetableCreation SelectSubject(String subject) 
	{
		System.out.println("Select subject");
		Select ddl = new Select(subjectselection);
		ddl.selectByVisibleText(subject);
		return this;
	}//SelectSubject end
	
	public TimetableCreation SelectDay(String day) 
	{
		System.out.println("Select day");
		Select ddl = new Select(dayselection);
		ddl.selectByVisibleText(day);
		return this;
	}//SelectDay end

	public TimetableCreation SelectSlot(String slot) 
	{
		System.out.println("Select slot");
		Select ddl = new Select(slotselection);
		ddl.selectByVisibleText(slot);
		return this;
	}//SelectSlot end
	
	
	public TimetableCreation SelectRoom(String room) 
	{
		System.out.println("Select Room");
		Select ddl = new Select(roomselection);
		ddl.selectByVisibleText(room);
		return this;
	}
	
	public TimetableCreation SelectCheackbox() 
	{
		System.out.println("inside SelectCheackbox function ");
		boolean isSelected1 = checkBoxElement1.isSelected();
		boolean isSelected2 = checkBoxElement1.isSelected();

		//performing click operation if element is not checked
		if(isSelected1 == false) 
		{
			checkBoxElement1.click();
		}
		if(isSelected2 == false) 
		{
			checkBoxElement2.click();
		}
		return this;
	}
	
	public TimetableCreation DeselectCheackbox() 
	{
		System.out.println("inside DeselectCheackbox function ");
		boolean isSelected1 = checkBoxElement1.isSelected();
		boolean isSelected2 = checkBoxElement2.isSelected();

		//performing click operation if element is not checked
		if(isSelected1 == true) 
		{
			checkBoxElement1.click();
		}
		if(isSelected2 == true) 
		{
			checkBoxElement2.click();
		}
		return this;
	}
	
	
	
	
	
	

}// AttendanceTimetableCreationPages class end