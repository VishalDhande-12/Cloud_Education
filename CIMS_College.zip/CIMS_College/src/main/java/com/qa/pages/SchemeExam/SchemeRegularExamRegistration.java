package com.qa.pages.SchemeExam;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.base.BaseClass;
import com.qa.pages.Exam.StudentExamRegistration;

public class SchemeRegularExamRegistration extends BaseClass {
	
	public SchemeRegularExamRegistration  (WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy (xpath = "/html/body/div[3]/aside[1]/section/div/ul/li[4]/ul/li[1]/ul/li[3]/a/span") private WebElement StuExamRegistration;
	//html/body/div[3]/aside[1]/section/div/ul/li[4]/ul/li[1]/ul/li[3]/a/span
	@FindBy (id = "ddlAcdSession") private WebElement AcademicSession;
	@FindBy (id = "ddlSession") private WebElement Session;
	@FindBy (id = "ddlBasicCourse") private WebElement BasicCourse;
	@FindBy (id = "ddlCourse") private WebElement Course; 
	@FindBy (id = "ddlScheme") private WebElement Scheme; 
	@FindBy (id = "ddlMedium") private WebElement Medium;
	@FindBy (id="ChkAll") private WebElement SelectAll;
	@FindBy (id="btnSubmit") private WebElement Submit;
	@FindBy (id = "btnLock") private WebElement LockBtn;
	@FindBy (id = "btnCancel") private WebElement Cancel;
	@FindBy (xpath="/html/body/div[3]/aside[2]/section/div/div/div/div[2]/div[1]") private WebElement confirmationmessage;
	
	public SchemeRegularExamRegistration OpenStuExamRegistration() {			
		click(StuExamRegistration);
		System.out.println("Open StuExamRegistration");
		return this;
	}		
	
	public SchemeRegularExamRegistration AcdSession() {
		System.out.println("Select AcademicSession");
		Select ddl = new Select(AcademicSession);
		ddl.selectByVisibleText("SESSION 2022-2023");
		return this;
	}
	
	public SchemeRegularExamRegistration Session() {
		System.out.println("selecte Exam Session");
		Select ddl = new Select(Session);
		ddl.selectByVisibleText("COLLEGE SESSION 2021 - 2022");
		return this;
	}
	
	public SchemeRegularExamRegistration BasicCourse() {
		System.out.println("selecte BasicCourse");
		Select ddl = new Select(BasicCourse);
		ddl.selectByVisibleText("BSC SEM 1");
		return this;
	}
	
	public SchemeRegularExamRegistration Course() {
		System.out.println("selecte Course");
		Select ddl = new Select(Course);
		ddl.selectByVisibleText("BSC SEM 1 - 1");
		return this;
	}
	
	public SchemeRegularExamRegistration Scheme() {
		System.out.println("selecte Scheme");
		Select ddl = new Select(Scheme);
		ddl.selectByVisibleText("(SESSION 2022-2023)");
		return this;
	}
	
	public SchemeRegularExamRegistration Medium() {
		System.out.println("selecte Medium");
		Select ddl = new Select(Medium);
		ddl.selectByVisibleText("ENGLISH");
		return this;
	}
	
	public SchemeRegularExamRegistration SelectAll() {
		System.out.println("Click on SelectAll");
		click(SelectAll);
		return this;
	}
	
	public SchemeRegularExamRegistration Submit() {
		System.out.println("Click on Submit");
		click(Submit);
		return this;
	}
	
	public SchemeRegularExamRegistration LockBtn() {
		System.out.println("Click on Lock");
		click(LockBtn);			
		return this;
		}
	
	public SchemeRegularExamRegistration Cancel() {
		System.out.println("Click on Cancel");
		click(Cancel);			
		return this;
		}
	
	public String verifyConfirmationMessage() {
		String confirmationMsg = getText(confirmationmessage);
		System.out.println("Confirmation Message - " + confirmationMsg );
		return confirmationMsg;
	}

	public SchemeRegularExamRegistration StartExamRegistrationScheme() throws Exception {
		OpenStuExamRegistration();
		AcdSession();
		Session();
		BasicCourse();
		Course();
		Scheme();
		Medium();
		Thread.sleep(2000);
		SelectAll();
		Thread.sleep(2000);
		Submit();
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10 /*timeout in seconds*/);
			if(wait.until(ExpectedConditions.alertIsPresent())==null) {  
			    System.out.println("alert was not present");
			   
			} else {
			    Alert alert = driver.switchTo().alert();
			    alert.getText();
			    alert.accept();			   
			    System.out.println("alert was present and accepted");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
		Thread.sleep(2000);
		
		return this;
	
}
}