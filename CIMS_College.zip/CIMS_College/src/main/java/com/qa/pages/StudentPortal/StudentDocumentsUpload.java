package com.qa.pages.StudentPortal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class StudentDocumentsUpload extends BaseClass {

	public StudentDocumentsUpload(WebDriver rdriver)
	{
		driver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy (xpath = "//*[@id=\"myTab\"]/li[7]/a/span/i") private WebElement SelectDocumentsUploadUrl;
	@FindBy (id = "ddlDocument") private WebElement ddlDocument;
	@FindBy (id = "btnSubmitDoc") private WebElement btnSubmitDoc;
	
	public StudentDocumentsUpload SelectDocumentsUploadUrl() {
		System.out.println("click on  Select Documents UploadUrl");
		click(SelectDocumentsUploadUrl);
		return this;
	}
	
	public StudentDocumentsUpload DocumentsUpload()
	{
		System.out.println("click on Select Document");
		Select ddl = new Select(ddlDocument);
		ddl.selectByVisibleText("AADHAR CARD NEW");
		return this;
	}
	
	public StudentDocumentsUpload Browse() {
		System.out.println("click on Browse");
		driver.findElement(By.id("image11")).sendKeys("D:\\OfficeTesting\\Automation\\AutomationOnEclipseGit\\testing_automation\\TestingDocuments\\ADHAR_CARD.jpg");
		return this;
	}
	
	public StudentDocumentsUpload btnSubmitDoc() {
		System.out.println("click on btnSubmitDoc");
		click(btnSubmitDoc);
		return this;
	}
}
