package com.qa.pages.StudentPortal;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;

public class DashboardLinks extends BaseClass {

	HomePageAdmin homePageAdmin;
	LoginPageAdmin loginPageAdmin;
	DashboardLinks dashboardLinks;
	
	
	public DashboardLinks(WebDriver rdriver)
	{
		driver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy ( xpath = "//*[@id=\"studentMenus\"]/li[2]/a/span" ) private WebElement ProfileLink;
	
	


	public DashboardLinks openProfileLink()
	{
		System.out.println("Click on Profile Link");
		click(ProfileLink);
		return this;
	}
	
	
	
	
	
	}
	


