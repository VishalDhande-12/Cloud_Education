package com.qa.pages.attendance;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.BaseClass;

public class ClassTimetableCreation extends BaseClass
{

	public ClassTimetableCreation(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (xpath = "(.//*[normalize-space(text()) and normalize-space(.)='Student Attendance Registration'])[1]/following::span[1]") private WebElement opentimetable;
	@FindBy (xpath = "(.//*[normalize-space(text()) and normalize-space(.)='Time Table Creation'])[1]/following::span[1]") private WebElement openclasstimetable;
	@FindBy (id = "4718~223517~3000890~2859") private WebElement drag;//BSC PR BATCH -> ENGLISH-ENGLISH -> QUALITY ASSURANCE
	@FindBy (id = "4718~223516~3000890~2859") private WebElement drag1;
	@FindBy (id = "4718~218938~3000890~2859") private WebElement drag2;
	@FindBy (id = "4718~226399~3000890~0") private WebElement drag3;
	@FindBy (id = "4718~218938~3000890~0") private WebElement drag5;
	@FindBy (id = "droppable1") private WebElement drop1;
	@FindBy (id = "droppable2") private WebElement drop2;
	@FindBy (id = "droppable3") private WebElement drop3;
	@FindBy (id = "droppable4") private WebElement drop4;
	@FindBy (id = "droppable5") private WebElement drop5;
	@FindBy (id = "droppable6") private WebElement drop6;
	@FindBy (id = "droppable7") private WebElement drop7;
	@FindBy (id = "droppable8") private WebElement drop8;
	@FindBy (id = "droppable9") private WebElement drop9;
	@FindBy (id = "droppable10") private WebElement drop10;
	@FindBy (id = "") private WebElement drop11;
	@FindBy (id = "") private WebElement drop12;
	@FindBy (id = "") private WebElement drop13;
	@FindBy (id = "") private WebElement drop14;
	@FindBy (id = "") private WebElement drop15;
	@FindBy (id = "") private WebElement drop16;
	@FindBy (id = "") private WebElement drop17;
	@FindBy (id = "") private WebElement drop18;
	@FindBy (id = "") private WebElement drop19;
	//@FindBy(xpath = "//*[@id=\\'rhs\\']/li")private List<WebElement> draggable;//*[@id="rhs"]/li[3] //*[@id="rhs"]/li[2]
	//@FindBy(xpath = "")private List<WebElement> droppable;
	List<WebElement> p = driver.findElements(By.xpath("//*[@id=\'rhs\']/li"));

	//@FindBy (id = "droppable"'+i+') private WebElement dropable;
	@FindBy (className = "close") private WebElement closetimetableslot;


	//test


	// (.//*[normalize-space(text()) and normalize-space(.)='Student Attendance Registration'])[1]/following::span[1]
	public ClassTimetableCreation OpenTimetable()
	{
		System.out.println("Open Timetable");
		click(opentimetable);
		return this;
	}// OpenTimetable end

	public ClassTimetableCreation OpenClassTimetable()
	{
		System.out.println("Open class Timetable");
		click(openclasstimetable);
		return this;
	}// OpenClassTimetable end

	public ClassTimetableCreation DragAndDrop() throws InterruptedException 
	{
		System.out.println("inside function DragAndDrop");
		//Creating object of Actions class to build composite actions  
		Actions act = new Actions(driver);  
		//Performing the drag and drop action  
		act.dragAndDrop(drag,drop2).build().perform();
		System.out.println("\n 1");
		act.dragAndDrop(drag,drop1).build().perform(); 
		System.out.println("\n 2");
		act.dragAndDrop(drag1,drop3).build().perform();
		System.out.println("\n 3");
		act.dragAndDrop(drag,drop6).build().perform();
		System.out.println("\n 4");
		act.dragAndDrop(drag,drop4).build().perform();
		System.out.println("\n 5");
		act.dragAndDrop(drag2,drop6).build().perform();
		System.out.println("\n 6");
		act.dragAndDrop(drag3,drop5).build().perform();
		System.out.println("\n 7");
		act.dragAndDrop(drag3,drop7).build().perform();
		System.out.println("\n 8");
		act.dragAndDrop(drag1,drop10).build().perform();
		System.out.println("\n 9");
		act.dragAndDrop(drag5,drop8).build().perform();
		System.out.println("\n 10");
		act.dragAndDrop(drag3,drop9).build().perform();
		System.out.println("\n 11");



		return this;
	}// DragAndDrop end

	public ClassTimetableCreation DeleteOldTimetable() throws InterruptedException 
	{
		System.out.println("inside function DeleteOldTimetable");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.MILLISECONDS);
	    scrollIntoView(drop1, 0, 2000);
	   // Actions action = new Actions(driver);   
	    //action.sendKeys(Keys.chord( Keys.CONTROL + "-")).perform();	    
	    for(int i=1;i<=5;i++)
		{
			for(int j=2;j<=8;j++)
			{
				//Thread.sleep(1000);
				try 
				{
					String closeimagexpath="/html/body/div[3]/aside[2]/section/div/div/div[2]/div[2]/div[2]/div[3]/div/div[2]/div/table/tbody/tr["+i+"]/td["+j+"]/li/img";
					System.out.println("Current close image xpath is= \n"+closeimagexpath);
					driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);			
					//driver.findElement(By.xpath(closeimagexpath)).click();
					Actions action = new Actions(driver);
					WebElement element= driver.findElement(By.xpath(closeimagexpath));
					action.moveToElement(element).click().perform();
					Alert alert =driver.switchTo().alert();
					String expectedresult=alert.getText();
					System.out.println("alert is =" +expectedresult);
					alert.accept();
					System.out.println("deleted slot "+i);
				} 
				catch (Exception e) 
				{
					//e.printStackTrace();
					System.out.println("either slot not available or teacher is not already allotted to slot");
				}
			}
		}
		
		return this;
	}//DeleteOldTimetable end


	public boolean isAlertPresent() 
	{ 
		try 
		{ 
			driver.switchTo().alert(); 
			return true; 
		}   // try 
		catch (NoAlertPresentException Ex) 
		{ 
			return false; 
		}   // catch 
	}   // isAlertPresent()

	public ClassTimetableCreation SetScreenResolution(int a, int b)
	{
	    Dimension dimension = new Dimension(a, b);
	    driver.manage().window().setSize(dimension);

	    return this;
	}
	
	
	public ClassTimetableCreation DragAndDropNew() throws InterruptedException 
	{
		System.out.println("inside function DragAndDropNew");

		for(int i=1;i<=9;i++)
		{
			System.out.println("inside for loop i="+i);
			String dropelement="droppable"+i;
			String dragelement= "//*[@id=\"rhs\"]/li["+i+"]";
			System.out.println("dropelement="+dropelement+"\n dragelement="+dragelement);
			Actions act = new Actions(driver);
			WebElement drop = driver.findElement(By.id(dropelement));
			WebElement drag = driver.findElement(By.xpath(dragelement));
			//Performing the drag and drop action  
			act.dragAndDrop(drag,drop).build().perform();
			Thread.sleep(1000);
			boolean isalertpresent= isAlertPresent();
			if(isalertpresent)
			{
				Alert alert=driver.switchTo().alert();
				System.out.println("alert text="+ alert.getText());
				alert.accept();
			}
			
		}


		return this;
	}
	
	
	



}// AttendanceTimetableCreationPages class end