package com.qa.pages.StudentsCertificates;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.BaseClass;

public class StudentsTc extends BaseClass{
	
	public StudentsTc(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (id = "ddlSession") private WebElement ddlSession;
	@FindBy (id = "ddlBasicCourse") private WebElement ddlBasicCourse;
	@FindBy (id = "ddlCourse") private WebElement CourseYearStandard;
	@FindBy (id = "ddlSearchBy") private WebElement ddlSearchBy;
	@FindBy (id = "txtSearch") private WebElement SearchText;
	//@FindBy(css = "div.eac-item")private List<WebElement> studentlist;
	@FindBy (id = "eac-container-txtSearch") private WebElement studentlist;
	@FindBy (id = "btnShow") private WebElement btnShow;
	@FindBy (id = "txtConduct") private WebElement txtConduct;
	@FindBy (id = "txtProgress") private WebElement txtProgress;
	@FindBy (id = "txtReason") private WebElement txtReason;
	@FindBy (id = "ddlTcFormat") private WebElement ddlTcFormat;
	@FindBy (id = "btnPreview") private WebElement btnPreview;
	@FindBy (id = "btnReport") private WebElement btnFinalReport;
	
	public StudentsTc openddlSession() {
		System.out.println("Select ddlSession -> 2026-2027-D");
		Select ddl = new Select(ddlSession);
		ddl.selectByVisibleText("2026-2027-D");
		return this;
	}
	
	public StudentsTc ddlBasicCourse() {
		System.out.println("Select ddlBasicCourse - SOFTWARE TESTING");
		Select ddl = new Select(ddlBasicCourse);
		ddl.selectByVisibleText("SOFTWARE TESTING");
		return this;
	}
	
	public StudentsTc CourseYearStandard() {
		System.out.println("Select CourseYearStandard - > SOFTWARE TESTING - 1");
		Select ddl = new Select(CourseYearStandard);
		ddl.selectByVisibleText("SOFTWARE TESTING - 1");
		return this;
	}
	
	public StudentsTc ddlSearchBy() {
		System.out.println("Select ddlSearchBy - Name");
		Select ddl = new Select(ddlSearchBy);
		ddl.selectByVisibleText("Name");
		return this;
	}
	
	public StudentsTc SearchText() throws Exception {
		System.out.println("Enter SearchName");
		sendKeys(SearchText,"___");
//		for (int i=0; i < studentlist.size(); i++) {
//			if(studentlist.get(i).getText().equalsIgnoreCase("___")) {
//				Thread.sleep(1000);
//				studentlist.get(i).click();
//				break;
//			}
//		}
		//Instantiating Actions class
		Thread.sleep(1000);
		Actions actions = new Actions(driver);
		
		//To mouseover on ..
		Thread.sleep(1000);
		actions.moveToElement(studentlist);
		
		//build()- used to compile all the actions into a single step
		Thread.sleep(1000);
		actions.click().build().perform();
		return this;
	}
	
	public StudentsTc btnShow() {
		System.out.println("Click btnShow");
		click(btnShow);
		return this;
	}
	
	public StudentsTc txtConduct() {
		System.out.println("Enter txtConduct");
		sendKeys(txtConduct,"ExamOfficerA1");
		return this;
	}
	
	public StudentsTc txtProgress() {
		System.out.println("Enter txtProgress");
		sendKeys(txtProgress,"Better");
		return this;
	}
	
	public StudentsTc txtReason() {
		System.out.println("Enter txtReason -> Student's family going out of stattion parmently");
		sendKeys(txtReason,"Student's family going out of stattion parmently");
		return this;
	}
	
	public StudentsTc ddlTcFormat() {
		System.out.println("Enter ddlTcFormat - JUNIOR(L)");
		Select ddl = new Select(ddlTcFormat);
		ddl.selectByVisibleText("JUNIOR(L)");
		return this;
	}
	
	public StudentsTc btnPreview() {
		System.out.println("Click btnPreview");
		click(btnPreview);
		return this;
	}
	
	public StudentsTc btnFinalReport() {
		System.out.println("Click btnFinalReport");
		click(btnFinalReport);
		return this;
	}

}
