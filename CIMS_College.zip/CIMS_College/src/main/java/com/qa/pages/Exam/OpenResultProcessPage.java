package com.qa.pages.Exam;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.BaseClass;



public class OpenResultProcessPage extends BaseClass {
	
	public OpenResultProcessPage(WebDriver rdriver)
	{
		driver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy (xpath = "(.//*[normalize-space(text()) and normalize-space(.)='Result Processing'])[1]/following::span[1]") private WebElement ResulProcessPage;
	//@FindBy (xpath = "/html/body/div[3]/aside[1]/section/ul/li[4]/ul/li[4]/ul/li[34]/a/span") private WebElement ResulProcessPage;
	
	
	public OpenResultProcessPage OpenResultProcessActualPage() throws Exception {
		System.out.println("ResulProcessPage");	
		Thread.sleep(2000);
		click(ResulProcessPage);
		
		return this;
	}
	
		
}
