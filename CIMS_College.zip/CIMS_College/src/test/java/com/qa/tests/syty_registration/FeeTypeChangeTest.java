package com.qa.tests.syty_registration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.syty_registeration.FeeTypeChange;
import com.qa.utilities.ExcelReader;

public class FeeTypeChangeTest extends BaseClass {

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	
	FeeTypeChange feeTypeChange;

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;

	public static WebDriver driver;

	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	@AfterClass
	public void afterClass() {
	}

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception {

		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "******Starting Test: " + m.getName() + "*****" + "\n");
	}

	@AfterMethod
	public void afterMethod() {
	}

	@Test()

	public void Fee_Type_Change() throws IOException, InterruptedException{

		loginPage = new LoginPageAdmin(driver);

		homePage = loginPage.login(loginUsers.getJSONObject("SupportA").getString("userName"),
				loginUsers.getJSONObject("SupportA").getString("password"));

		Thread.sleep(1000);
		System.out.println("Fee Type Change");
		driver.get("https://cims.mastersofterp.in/FeeTypeChange/FeeTypeChange");

		System.out.println("2023-2024");
		driver.findElement(By.id("ddlSession")).sendKeys("2023-2024");

		new Select(driver.findElement(By.id("ddlBasicCourse"))).selectByVisibleText("11TH COMMERCE");

		new Select(driver.findElement(By.id("ddlCourse"))).selectByVisibleText("11TH COMMERCE");

		// acceptAlert();

		new Select(driver.findElement(By.id("ddlSearchBy"))).selectByVisibleText("Student Id");

//		WebElement Input = driver.findElement(By.id("userInput"));
////		// Input.sendKeys("4528833");
//		Input.sendKeys();
		// System.out.println(Input);
		
		Thread.sleep(1000);
		feeTypeChange.enterInputName();

		Thread.sleep(1000);
		WebElement StudSearchBox = driver.findElement(By.className("ui-menu-item"));
		Thread.sleep(1000);
		Actions actions = new Actions(driver);
		Thread.sleep(1000);
		actions.moveToElement(StudSearchBox);
		Thread.sleep(1000);
		actions.click().build().perform();
		// System.out.println(StudSearchBox);

		Thread.sleep(1000);
		new Select(driver.findElement(By.id("ddlNewFeecategory"))).selectByVisibleText("FULL PAY");

		Thread.sleep(1000);
		driver.findElement(By.id("btnSubmit")).click();
		System.out.println("Click on Submit");

		System.out.println("Assertion give below");
		String actualConfiramationTxt = "Saved Successfully!";
		String expectedConfiramationTxt = "Saved Successfully!";
		System.out.println("Actual Confirmation Text - " + actualConfiramationTxt + "\n"
				+ "Expected Confiramtion Text - " + expectedConfiramationTxt);
		Assert.assertEquals(actualConfiramationTxt, expectedConfiramationTxt);

		Thread.sleep(5000);

	}

	// Excel

	public FeeTypeChangeTest Excel(String name) throws IOException {
		WebElement Input = driver.findElement(By.id("userInput"));
		System.out.println("Search Student -> Enter Input");
		sendKeys(Input, name);
		return this;
	}
	
	public FeeTypeChangeTest ExcelA() throws IOException {
		WebElement Input = driver.findElement(By.id("userInput"));
		System.out.println("Search Student -> Enter Input");
		File file = new File(".\\src\\test\\resources\\excel\\testdata11.xlsx");
		FileInputStream inputStream = new FileInputStream(file);
		try (Workbook workbook = new XSSFWorkbook(inputStream)) {
			Sheet sheet = workbook.getSheetAt(0);
			int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum(); // Find number of rows in excel file
			System.out.println(rowCount);
			for (int i = 6; i <= 10; i++) {
				Row row = sheet.getRow(i);
				sendKeys(Input, row.getCell(3).getStringCellValue());
			}
		}
		return this;
	}

//	////Excel is start
//	public void readExcel(String filePath,String fileName,String sheetName) throws IOException{
//
//	    //Create an object of File class to open xlsx file
//
//	    File file =    new File(filePath+"D:\\OfficeTesting\\Automation\\AutomationOnEclipseGit\\testing-automation\\CIMS_College\\src\\test\\resources\\excel\\MCCJUNIOR_SUPPORT6@PTVA.COM_JxiZWpea.xlsx"+fileName);
//
//	    //Create an object of FileInputStream class to read excel file
//
//	    FileInputStream inputStream = new FileInputStream(file);
//
//	    Workbook guru99Workbook = null;
//
//	    //Find the file extension by splitting file name in substring  and getting only extension name
//
//	    String fileExtensionName = fileName.substring(fileName.indexOf("."));
//
//	    //Check condition if the file is xlsx file
//
//	    if(fileExtensionName.equals(".xlsx")){
//
//	    //If it is xlsx file then create object of XSSFWorkbook class
//
//	    guru99Workbook = new XSSFWorkbook(inputStream);
//
//	    }
//
//	    //Check condition if the file is xls file
//
//	    else if(fileExtensionName.equals(".xls")){
//
//	        //If it is xls file then create object of HSSFWorkbook class
//
//	        guru99Workbook = new HSSFWorkbook(inputStream);
//
//	    }
//
//	    //Read sheet inside the workbook by its name
//
//	    Sheet guru99Sheet = guru99Workbook.getSheet(sheetName);
//
//	    //Find number of rows in excel file
//
//	    int rowCount = guru99Sheet.getLastRowNum()-guru99Sheet.getFirstRowNum();
//
//	    //Create a loop over all the rows of excel file to read it
//
//	    for (int i = 0; i < rowCount+1; i++) {
//
//	        Row row = guru99Sheet.getRow(i);
//
//	        //Create a loop to print cell values in a row
//
//	        for (int j = 0; j < row.getLastCellNum(); j++) {
//
//	            //Print Excel data in console
//
//	            System.out.print(row.getCell(j).getStringCellValue()+"|| ");
//
//	        }
//
//	        System.out.println();
//	    } 
//
//	    }  
//
//	    //Main function is calling readExcel function to read data from excel file
//
//	    public static void main(String...strings) throws IOException{
//
//	    //Create an object of ReadGuru99ExcelFile class
//
//	    ReadGuru99ExcelFile objExcelFile = new ReadGuru99ExcelFile();
//
//	    //Prepare the path of excel file
//
//	    String filePath = System.getProperty("user.dir")+"\\src\\excelExportAndFileIO";
//
//	    //Call read file method of the class to read data
//
//	    objExcelFile.readExcel(filePath,"ExportExcel.xlsx","ExcelGuru99Demo");
//
//	    }

}
