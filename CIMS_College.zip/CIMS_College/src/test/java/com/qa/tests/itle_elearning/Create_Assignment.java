package com.qa.tests.itle_elearning;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.qa.base.BaseClass;



public class Create_Assignment extends BaseClass {
	
	public static void main(String args[]) throws InterruptedException {

		 System.setProperty(
		            "webdriver.chrome.driver","C:\\ChromeDriver\\chromedriver.exe");
        // Instantiate a ChromeDriver class.
//		WebDriverManager.chromedriver().setup();
	 	WebDriver driver = new ChromeDriver();
//	 	
//	 	ChromeOptions chromeOptions = new ChromeOptions();
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver = new ChromeDriver(chromeOptions);
 
        // Maximize the browser
        driver.manage().window().maximize();
 
        // Launch Website
        driver.get("https://rfctest.mastersofterp.in");
        
        driver.findElement(By.id("txt_username")).sendKeys("2021067");
        Thread.sleep(1000);
        driver.findElement(By.id("txt_password")).sendKeys("rfctest@dev");
        driver.findElement(By.id("txtcaptcha")).click();
        Thread.sleep(5000);
        driver.findElement(By.id("btnLogin")).click();
        System.out.println("click on btnLogin");
        Thread.sleep(3000);
        
        driver.get("https://rfctest.mastersofterp.in/Itle/iitmsqnjSoNwsdxzxnzdVWjPXLvej6dG7UW1M/eO/cHrM5W3654IEEnhkMQcJxv5qDm8h?enc=M1EsHDAeRhaekcwzmtddkgSMXGqH2lTtm+b7iayaI9M=");
        System.out.println("click on Select Course");
      
//        driver.findElement(By.linkText("E- LEARNING")).click();
//        System.out.println("click on E- LEARNING");
//        Thread.sleep(5000);
//        driver.findElement(By.linkText("Transactions")).click();
//        System.out.println("click on Transactions");
//        Thread.sleep(5000);
//        driver.findElement(By.id("ctl00_repLinks_ctl00_lbLink")).click();

        
        Thread.sleep(1000);
        driver.findElement(By.id("select2-ctl00_ContentPlaceHolder1_ddlSession-container")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@class='select2-search__field']")).sendKeys("May 2022 - School of Social Sciences and Humanities");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@class='select2-search__field']")).sendKeys(Keys.ENTER);
        System.out.println("click on Session");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_RpCourse_ctl00_btnlncardkSelect\"]/div/div/div/div[1]/table/tbody/tr[1]/th/span[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[2]/div/div[6]/button[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("ctl00_repLinks_ctl01_lbLink")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_txtTopic\"]")).sendKeys("Assignment 1");
        Thread.sleep(2000);
        
        System.out.println("Description");
        //driver.switchTo().window(null);
        driver.switchTo().frame(0);
        // Now, interact with elements inside the frame
        WebElement frameElement = driver.findElement(By.cssSelector("#cke_contents_ctl00_ContentPlaceHolder1_txtDescription"));
        // Perform actions on elements inside the frame
        System.out.println(frameElement.getText());
        //frameElement.sendKeys("Test0");
        
//        //switchToNextWindow();
//        WebElement dynamicIframeId = driver.findElement(By.id("cke_contents_ctl00_ContentPlaceHolder1_txtDescription"));
//        Thread.sleep(2000);
//        //driver.switchTo().frame(dynamicIframeId); 
//        dynamicIframeId.sendKeys("Test0");
        
        //driver.switchTo().frame(1);
        System.err.println("test0");
        System.out.println(driver);
        
        
        driver.findElement(By.id("cke_contents_ctl00_ContentPlaceHolder1_txtDescription")).sendKeys("what is ASP?");
        
        Thread.sleep(8000);
        driver.close();
        
	}
}
