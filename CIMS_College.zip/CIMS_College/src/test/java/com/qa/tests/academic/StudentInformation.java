package com.qa.tests.academic;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.HomePageStudent;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.LoginPageStudent;
import com.qa.pages.StudentPortal.DashboardLinks;
import com.qa.pages.StudentPortal.PhotoAndSign;
import com.qa.pages.StudentPortal.Profile;
import com.qa.pages.StudentPortal.ProfileAddress;
import com.qa.pages.StudentPortal.StudentDocumentsUpload;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;

public class StudentInformation extends BaseClass {
	
	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	DashboardLinks dashboardLinks;
	
	InputStream dataIs;
	JSONObject loginUsers;
	
	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass() {
	}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsAdmin");
		
		System.out.println("\n" + "*******Starting Test : Student Information : " + m.getName() + "*******" + "\n");
			}
	
	@AfterMethod
	public void afterMethod() {
	}
	
	@Test()
	
	public void Profile() throws IOException, Exception {
		
		loginPage = new LoginPageAdmin(driver);
		dashboardLinks = new DashboardLinks(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		

		System.out.println("open Student Information page");
		Thread.sleep(2000);
		driver.get("http://cimsuat.mastersofterp.in/StudentInformation/Index#");
		
		Thread.sleep(2000);
		System.out.println("Enter ddlSession -> SESSION 2022-2023");
		Select ddlSession = new Select(driver.findElement(By.id("ddlSession")));
		ddlSession.selectByVisibleText("SESSION 2022-2023");
		
		Thread.sleep(2000);
		System.out.println("Enter ddlBasicCourse -> BSC SEM 1");
		Select ddlBasicCourse = new Select(driver.findElement(By.id("ddlBasicCourse")));
		ddlBasicCourse.selectByVisibleText("BSC SEM 1");
		
		Thread.sleep(2000);
		System.out.println("Enter ddlCourse -> BSC SEM 1 - 1");
		Select ddlCourse = new Select(driver.findElement(By.id("ddlCourse")));
		ddlCourse.selectByVisibleText("BSC SEM 1 - 1");
		
		Thread.sleep(1000);
		System.out.println("Search By - Name");
		driver.findElement(By.id("sname")).click();
		
		Thread.sleep(1000);
		System.out.println("Enter Name ___");
		driver.findElement(By.id("userInput")).sendKeys("___");
		Thread.sleep(1000);
		driver.findElement(By.id("userInput")).sendKeys(Keys.DOWN);
		Thread.sleep(1000);
		driver.findElement(By.id("userInput")).sendKeys(Keys.ENTER);
		
		Thread.sleep(2000);
		System.out.println("click on PhotoAndSignatureDetails");
		driver.findElement(By.linkText("PHOTO AND SIGNATURE DETAILS")).click();
		
		Thread.sleep(1000);
		System.out.println("Upload Student Photo");
		driver.findElement(By.id("btnCropPhoto")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("file")).sendKeys("D:\\OfficeTesting\\Automation\\AutomationOnEclipseGit\\testing_automation\\TestingDocuments\\MalePic.jpg");
		Thread.sleep(1000);
		driver.findElement(By.id("uploadphoto")).click();
		
		Thread.sleep(1000);
		System.out.println("Upload Student Sign");
		driver.findElement(By.id("btnCropSign")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("file_sign")).sendKeys("D:\\OfficeTesting\\Automation\\AutomationOnEclipseGit\\testing_automation\\TestingDocuments\\Signature.png");
		Thread.sleep(1000);
		driver.findElement(By.id("uploadsign")).click();
		
		Thread.sleep(2000);
		System.out.println("Click on Submit");
		driver.findElement(By.id("btnSubmit")).click();

		Thread.sleep(5000);
		Utilities.getAShot();
	}

}
