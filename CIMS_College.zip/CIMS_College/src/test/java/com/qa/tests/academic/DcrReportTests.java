package com.qa.tests.academic;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.academic.Academic;
import com.qa.pages.academic.DcrReport;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;

public class DcrReportTests extends BaseClass {
	
	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Academic academic;
	DcrReport dcrReport;

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass() {
}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsAdmin");
		
		System.out.println("\n" + "******Starting Test: " + m.getName() + "*****" + "\n");
	}
	
	@AfterMethod
	public void afterMethod() {
	}
	
	@Test()
	
	public void User_Able_To_Generate_DCR_Report() throws IOException, Exception {
	
		loginPage = new LoginPageAdmin(driver);
		academic = new Academic(driver);
		dcrReport = new DcrReport(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"), 
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		Thread.sleep(1000);
		homePage.openAcademic();
		
		//acceptAlert();
		Thread.sleep(1000);
		academic.openFeesReports();
		
		Thread.sleep(1000);
		academic.openFeesReport();
		
		Thread.sleep(1000);
		academic.openDcrReport();
		
		
		Thread.sleep(1000);
		dcrReport.DETAILED();
		
		Thread.sleep(1000);
		dcrReport.ddlSession();
		
		Thread.sleep(1000);
		dcrReport.ddlReceiptType();
		
		Thread.sleep(1000);
		dcrReport.ddlCashBookType();
		
		Thread.sleep(1000);
		dcrReport.DateTo();
		
		Thread.sleep(1000);
		dcrReport.DateFrom();
		
		Thread.sleep(1000);
		dcrReport.btnReport();
		
		Thread.sleep(5000);
		switchToNextWindow();
		
		Thread.sleep(10000);
		Utilities.getAScreenShot();
		
		Thread.sleep(1000);
		//dcrReport.verifyPDFContent("https://cims.mastersofterp.in/CommonReport/New_ShowGeneralReport?data=dAi2DAkbGrhciHwwMKDmuv+R/yeiXaAcCaaTni8Fyyw7x3R9Xo5KqVahN2VQl/jQ0K36JAHF0AlgDgp9dLw+tR1+8LXOHbZCTJoX1bQgTLk5u5Ny+R1NlaW9luKUNusucYktph1SvcoLtS408eShk20VKtYUgpSifhx+fzcFzsBpci5VF8PkRPKRcWDWOy6J/AWL0+r8w0N5q7nBfNaoK50pnhAgkibQI5/prfKqNjSW2iOUrrx/kO9nW2+qCvKscgIrs5aamxXGInM/og4RMREAg8u+Aed6RsmzPGlQIPi1BOtOcheyTtnN2VctN0kl0XUbEXD5hDYA2XynZf2P2ENvZxwXSxBWy2fMUjtVXbiGVBQRZNnXYHIk32NiHBuoE9w7h+/F1kzc5MfNsO30d1PsxjBuo1gF+75nqw3LQGwnzIH8016nz3SqeJYz4o7YBZSYmG6qT9Yb0s+2QZ3NYw+izS+RV4S1Suvs79SdHpsHKyajLCIUdVwJuaREO5pA2GZ2IkQkEvYohRghm//V5R0rrMmcBYYInvoGAaupyVzTqqpdG5Wfaqb8ozhu/B369tRx8XtMnY7HSvyvJihzUEHho8qLRruSrDwBa1srdxNWdhI/XaU5RLlOYIW3aUjYGND68FdFkTtqteg4J/mgqLazlw2sf5xPRdNfO5ML2qqwc6DIklD3pKgPBgkMSf1Nvsj3wVIq7tRqXwh7P0v6J88NdUCA9+X5EUtECTIJLgkp4U0ulYvYDfbAQtulYSUD8zEJ4FkocpNa6eGfxHeadXhLpO9UrMgqYt7Nq8lAEDaT0NpZQIQpRDaq6KNdBMIPDo5FkCHEinvgXswOlBe2Wf85jtnOqI7ibN5Zv5gS9938UKOBo1cxOb2V/AFrTroeh5z8qoTaWroxC9+Jtm/RThqKNrgkazVDACZVla8gHg7CGucm+tBR4g8cQ3Bqnh8hfMGuIzIeSR5Q1cIRJeeXBmwiUK5rwPq8/S3rat+n0BSVGMIP0AHza8SAps+RwLsP80SSnqUh86eL63JOpLLahPNfnbWMFx71/ycaIf7SicYkNY9gfIoTkkNhGKxL5oo0wQsWDHX/PZ6NF4Kadc5oaP3Pa3qtId7pJCSYTHGGhKlAjrj5sYx+wRkdjufI1FfxrxEk5V+ENIEYmdNsUsnFeM6v+Ye1tXnYfDbl8lrXmfAwby0YRP8oBgLMot1N2sQJZDzQ5ZCzcyqAju4BV6smasGOOZPZ4J6RPCmpR0nbfcpTxnGTSbAe//FT9/mne0ekpiIYkFxfbM0xO2ch2ws4/atIfNB7v2U3mPRz0NK4h5aAlfNQJCpnxCQuVUf7PshPH8AaH+Lqa9mMiEnWZyvDLg==", " QUALITY ASSURANCE");
		
	}
}

		
		
		
		
		
		
	