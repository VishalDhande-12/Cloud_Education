package com.qa.tests.payroll;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.payroll.AnnualPaySlipReport;
import com.qa.pages.payroll.Payroll;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;

public class AnnualPaySlipReportTests extends BaseClass {
	
	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Payroll payroll;
	AnnualPaySlipReport annualPaySlipReport;

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass() {
}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsAdmin");
		
		System.out.println("\n" + "******Starting Test: " + m.getName() + "*****" + "\n");
	}
	
	@AfterMethod
	public void afterMethod() {
	}
	
	@Test()
	
	public void AnnualPaySlipReport() throws IOException, Exception {
	
		loginPage = new LoginPageAdmin(driver);
		payroll = new Payroll(driver);
		annualPaySlipReport = new AnnualPaySlipReport(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"), 
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		Thread.sleep(1000);
		homePage.openPayroll();
		
		//acceptAlert();
		Thread.sleep(1000);
		payroll.openReport();
		
		Thread.sleep(1000);
		payroll.openReports();
		
		Thread.sleep(1000);
		payroll.openAnnualPaySlip();
		
		Thread.sleep(1000);
		annualPaySlipReport.FromDate();
		
		Thread.sleep(1000);
		annualPaySlipReport.ToDate();
		
		Thread.sleep(1000);
		annualPaySlipReport.ddlStaff();
		
		Thread.sleep(1000);
		annualPaySlipReport.ddlEmployee();
		
		Thread.sleep(1000);
		annualPaySlipReport.ddlEmployeeName();
		
		Thread.sleep(1000);
		annualPaySlipReport.btnShow();
		
		Thread.sleep(5000);
		switchToNextWindow();
		
		Thread.sleep(10000);
		Utilities.getAScreenShot();
		
	}
}

		
		
		
		
		
		
	