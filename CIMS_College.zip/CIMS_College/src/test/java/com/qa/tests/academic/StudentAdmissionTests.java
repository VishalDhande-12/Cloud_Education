package com.qa.tests.academic;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.academic.Academic;
import com.qa.pages.academic.StudentAdmission;
import com.qa.pages.academic.SubmitAndPay;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;




public class StudentAdmissionTests extends BaseClass {

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Academic academic;
	StudentAdmission studentAdmission;
	SubmitAndPay submitAndPay;

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass() {

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception {
		
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod() {
	}

	
	


	@Test(priority=1)
	public void Student_Admission_With_ZeroAmt_Fees_Amount() throws IOException, InterruptedException {

		loginPage = new LoginPageAdmin(driver);
		academic = new Academic(driver);
		studentAdmission = new StudentAdmission(driver);
		
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));

		Thread.sleep(1000);
		homePage.openAcademic();
		
		//acceptAlert();
		Thread.sleep(1000);
		academic.openTransaction();
		
		Thread.sleep(1000);
		academic.openCollectFees();
		
		Thread.sleep(1000);
		academic.openStudentAdmission();
		
		//Course Details
		Thread.sleep(1000);
		studentAdmission.selectBasicCourse();
		
		Thread.sleep(1000);
		studentAdmission.selectCourse();
		
		Thread.sleep(1000);
		studentAdmission.selectFeeType();
		
		Thread.sleep(1000);
		studentAdmission.selectStudentType();
		
		Thread.sleep(1000);
		studentAdmission.selectTitle();
		//Student Details
		
		Thread.sleep(1000);
		studentAdmission.enterLastName();
		
		Thread.sleep(1000);
		studentAdmission.enterFirstName();
		
		Thread.sleep(1000);
		studentAdmission.enterMiddleName();
		
		Thread.sleep(1000);
		studentAdmission.selectGender();
		
		Thread.sleep(1000);
		studentAdmission.selectCasteCategory();
		
		Thread.sleep(1000);
		studentAdmission.enterMothersName();
		
		Thread.sleep(1000);
		studentAdmission.enterFathersName();
		
		Thread.sleep(1000);
		studentAdmission.enterEnrollmentNumber();
		
		Thread.sleep(1000);
		studentAdmission.enterMobileNumber();
		
		Thread.sleep(1000);
		studentAdmission.enterEmail();
		
		Thread.sleep(1000);
		studentAdmission.enterRemark();
		
		Thread.sleep(1000);
		studentAdmission.checkAdmissionZeroAmt();
		
		//Subject Details
		Thread.sleep(1000);
		studentAdmission.clickOnAddSubjectButton();
		
		Thread.sleep(1000);
		studentAdmission.selectMedium();
		
		Thread.sleep(1000);
		studentAdmission.selectSubjectType();
		
		Thread.sleep(1000);
		studentAdmission.clickOnAdd();
		
		Thread.sleep(1000);
		studentAdmission.clickSubmitButton();
		
		Thread.sleep(1000);
		Utilities.getAShot();
		
		Thread.sleep(1000);
		String actualConfiramationTxt = studentAdmission.verifyConfirmationMessage();
		String expectedConfiramationTxt = "Record Saved Successfully!";
		System.out.println("Actual Confirmation Text - " + actualConfiramationTxt + "\n"
				+ "Expected Confiramtion Text - " + expectedConfiramationTxt);

		Assert.assertEquals(actualConfiramationTxt, expectedConfiramationTxt);
		
		Thread.sleep(1000);
		driver.close();

	}
	
	
	@Test(priority=2)
	public void Student_Admission_With_Direct_Submit() throws IOException, InterruptedException {

		loginPage = new LoginPageAdmin(driver);
		academic = new Academic(driver);
		studentAdmission = new StudentAdmission(driver);
		
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));

		Thread.sleep(1000);
		homePage.openAcademic();
		
		//acceptAlert();
		Thread.sleep(1000);
		academic.openTransaction();
		
		Thread.sleep(1000);
		academic.openCollectFees();
		
		Thread.sleep(1000);
		academic.openStudentAdmission();
		
		//Course Details
		Thread.sleep(1000);
		studentAdmission.selectBasicCourse();
		
		Thread.sleep(1000);
		studentAdmission.selectCourse();
		
		Thread.sleep(1000);
		studentAdmission.selectFeeType();
		
		Thread.sleep(1000);
		studentAdmission.selectStudentType();
		
		Thread.sleep(1000);
		studentAdmission.selectTitle();
		
		//Student Details
		Thread.sleep(1000);
		studentAdmission.enterLastName();
		
		Thread.sleep(1000);
		studentAdmission.enterFirstName();
		
		Thread.sleep(1000);
		studentAdmission.enterMiddleName();
		
		Thread.sleep(1000);
		studentAdmission.selectGender();
		
		Thread.sleep(1000);
		studentAdmission.selectCasteCategory();
		
		Thread.sleep(1000);
		studentAdmission.enterMothersName();
		
		Thread.sleep(1000);
		studentAdmission.enterFathersName();
		
		Thread.sleep(1000);
		studentAdmission.enterEnrollmentNumber();
		
		Thread.sleep(1000);
		studentAdmission.enterMobileNumber();
		
		Thread.sleep(1000);
		studentAdmission.enterEmail();
		
		Thread.sleep(1000);
		studentAdmission.enterRemark();
		
		//Subject Details
		Thread.sleep(1000);
		studentAdmission.clickOnAddSubjectButton();
		
		Thread.sleep(1000);
		studentAdmission.selectMedium();
		
		Thread.sleep(1000);
		studentAdmission.selectSubjectType();
		
		Thread.sleep(1000);
		studentAdmission.clickOnAdd();
		
		Thread.sleep(1000);
		studentAdmission.clickSubmitButton();
		
		Thread.sleep(1000);
		Utilities.getAShot();
		
		Thread.sleep(1000);
		String actualConfiramationTxt = studentAdmission.verifyConfirmationMessage();
		String expectedConfiramationTxt = "Record Saved Successfully!";
		System.out.println("Actual Confirmation Text - " + actualConfiramationTxt + "\n"
				+ "Expected Confiramtion Text - " + expectedConfiramationTxt);

		Assert.assertEquals(actualConfiramationTxt, expectedConfiramationTxt);
		
		Thread.sleep(1000);
		driver.close();

	}

	
	@Test(priority=3)
	public void Student_Admission_With_Submit_And_Pay() throws Exception {

		loginPage = new LoginPageAdmin(driver);
		academic = new Academic(driver);
		studentAdmission = new StudentAdmission(driver);
		submitAndPay = new SubmitAndPay(driver);

		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));

		Thread.sleep(1000);
		homePage.openAcademic();
		
		//acceptAlert();
		Thread.sleep(1000);
		academic.openTransaction();

		Thread.sleep(1000);
		academic.openCollectFees();
		
		Thread.sleep(1000);
		academic.openStudentAdmission();
		
		//Course Details
		Thread.sleep(1000);
		studentAdmission.selectBasicCourse();
		
		Thread.sleep(1000);
		studentAdmission.selectCourse();
		
		Thread.sleep(1000);
		studentAdmission.selectFeeType();
		
		Thread.sleep(1000);
		studentAdmission.selectStudentType();
		
		Thread.sleep(1000);
		studentAdmission.selectTitle();
		
		//Student Details
		Thread.sleep(1000);
		studentAdmission.enterLastName();
		
		Thread.sleep(1000);
		studentAdmission.enterFirstName();
		
		Thread.sleep(1000);
		studentAdmission.enterMiddleName();
		
		Thread.sleep(1000);
		studentAdmission.selectGender();
		
		Thread.sleep(1000);
		studentAdmission.selectCasteCategory();
		
		Thread.sleep(1000);
		studentAdmission.enterMothersName();
		
		Thread.sleep(1000);
		studentAdmission.enterFathersName();
		
		Thread.sleep(1000);
		studentAdmission.enterEnrollmentNumber();
		
		Thread.sleep(1000);
		studentAdmission.enterMobileNumber();
		
		Thread.sleep(1000);
		studentAdmission.enterEmail();
		
		Thread.sleep(1000);
		studentAdmission.enterRemark();
		
		//Subject Details
		Thread.sleep(1000);
		studentAdmission.clickOnAddSubjectButton();
		
		Thread.sleep(1000);
		studentAdmission.selectMedium();
		
		Thread.sleep(1000);
		studentAdmission.selectSubjectType();
		
		Thread.sleep(1000);
		studentAdmission.clickOnAdd();
		
		Thread.sleep(1000);
		studentAdmission.clickOnSaveAndPayButton();
		
		//SubmitAndPay
		Thread.sleep(1000);
		switchToFrame(0);
		
		Thread.sleep(1000);
		submitAndPay.enterRemark();
		
		Thread.sleep(1000);
		submitAndPay.selectADMThrough();
		
		Thread.sleep(1000);
		submitAndPay.selectPaymentOption();
		
		Thread.sleep(1000);
		submitAndPay.enterPaymentId();
		
		Thread.sleep(1000);
//		submitAndPay.selectPaymentMode("Cheque");
		submitAndPay.enterAmount();
		
		Thread.sleep(1000);
		submitAndPay.clickOnAddButton();
		
		Thread.sleep(2000);
		submitAndPay.clickOnAdjustFees();
		
		Thread.sleep(1000);
		submitAndPay.clickOnSubmitButton();
		
		Thread.sleep(1000);
		Utilities.getAShot();
		

//		String actualConfiramationTxt = studentAdmission.verifyConfirmationMessage();
//		String expectedConfiramationTxt = "Record Saved Successfully!";
//		System.out.println("Actual Confirmation Text - " + actualConfiramationTxt + "\n"
//				+ "Expected Confiramtion Text - " + expectedConfiramationTxt);
//
//		Assert.assertEquals(actualConfiramationTxt, expectedConfiramationTxt);

	}
	
}



