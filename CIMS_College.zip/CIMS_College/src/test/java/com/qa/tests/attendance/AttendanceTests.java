package com.qa.tests.attendance;

import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.attendance.Attendance;
import com.qa.pages.attendance.SessionCreation;
import com.qa.pages.attendance.TheoryBatchCreation;

public class AttendanceTests extends BaseClass
{

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
    Attendance attendance;
    SessionCreation session;
    TheoryBatchCreation theorybatch;
	InputStream dataIs;
	JSONObject loginUsers;

	public static WebDriver driver;
	
	@BeforeSuite
	public void beforeSuite() throws Exception 
	{
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	@BeforeClass
	public void beforeClass() throws Exception 
	{
//		try {
//			String dataFileName = "data/loginUsers.json";
//			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
//			JSONTokener tokener = new JSONTokener(dataIs);
//			loginUsers = new JSONObject(tokener);
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			if (dataIs != null) {
//				dataIs.close();
//			}
//		}
	}

	//testing add new feature
	
	@AfterClass
	public void afterClass()
	{

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception
	{
		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
		
		
	}
	@AfterMethod
	public void afterMethod()
	{

	}

	@BeforeTest
	private void beforeTest() throws Exception
	{
		driver = initializeDriverBFT("urlCimsAdmin");
		loginPage = new LoginPageAdmin(driver);
		attendance = new Attendance(driver);
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
	}
	
	

	@Test(priority = 1)
	public void User_Able_To_Create_Attendance_Session () throws Exception 
	{
		
		session = new SessionCreation(driver);
		homePage.openAttendance();
		attendance.OpenMaster();
		attendance.OpenCommonMaster();
		session.OpenAttendanceSession();
		session.SelectAcademicSession();
		session.EnterAttendanceSessioFullName();
		session.EnterAttendanceSessioShortName();
		//session.SelectSessionStartDate();
		session.SelectSessionStartDate("May","01");
		session.ClickOnSearch();
		session.selectSessionEndDate("April","30");

		attendance.ClickSubmitbutton();
		//attendance.ClickHomeIcon();

	}//Attendance_SessionCreation method end

//	@Test(priority = 2)
//	public void Attendance_TheorybatchCreation () throws IOException, InterruptedException 
//	{
//		theorybatch =new TheoryBatchCreation(driver);
//		homePage.openAttendance();	
//		attendance.OpenMaster();
//		attendance.OpenBatch();
//		theorybatch.OpenTheoryBatch();
//		attendance.SelectAttendanceSession();
//		Thread.sleep(2000);
//		theorybatch.EnterTheoryBatchShortName();
//		theorybatch.EnterTheoryBatchName();
//		//attendance.ClickSubmitbutton();
//		attendance.ClickHomeIcon();
//	}//Attendance_TheorybatchCreation end
//	
//	

	


}// StudentAttendanceRegistrationTests class end






















































//generalised method call for dropdown function
//attendance.dropdown("id", "ddlAttendanceSession","ATTENDANCE SESSION");
//attendance.dropdown("id", "ddlBasicCourse","BSC SEM 1");
//attendance.dropdown("id", "ddlCourse","BSC SEM 1 - 1");
//attendance.dropdown("id", "ddlSubject","HINDI--HINDI(1.00)");
//attendance.dropdown("id", "ddlTheoryBatch","BSC TH BATCH");
//attendance.dropdown("id", "ddlTeacher","QUALITY ASSURANCE");
