package com.qa.tests.attendance;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.attendance.Attendance;
import com.qa.pages.attendance.StudentTheoryBatchRegistration;

public class StudentTheoryBatchRegistrationTests extends BaseClass
{

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
    Attendance attendance;
    StudentTheoryBatchRegistration studentthbatchreg;
	InputStream dataIs;
	JSONObject loginUsers;

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception 
	{
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass()
	{

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception
	{
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod()
	{
	}

	
	
	
	@Test(priority = 1)
	public void Register_Student_For_Theory_Batch () throws IOException, Throwable
	{

		loginPage = new LoginPageAdmin(driver);
		attendance = new Attendance(driver);
		studentthbatchreg = new StudentTheoryBatchRegistration(driver);
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		Thread.sleep(1000);
		homePage.openAttendance();
		
		Thread.sleep(1000);
		attendance.OpenTransaction();
		
		Thread.sleep(3000);
		attendance.OpenRegistration();
		
		Thread.sleep(3000);
		studentthbatchreg.OpentheoryBatchStudentRegistration();
		
		Thread.sleep(2000);
		attendance.SelectAttendanceSession();
		
		Thread.sleep(1000);
		attendance.SelectBasiccourse();
		
		Thread.sleep(1000);
		attendance.SelectCourse("BSC SEM 1 - 1");
		
		Thread.sleep(1000);
		studentthbatchreg.SelectSubject();
		
		Thread.sleep(1000);
		attendance.SelectTheoryBatch();
		
		Thread.sleep(2000);
		studentthbatchreg.SelectTeacher();
		
		Thread.sleep(2000);
		attendance.CheackAllCheckbox();
		
		Thread.sleep(2000);
		//attendance.CheackAllCheckbox();
		//Thread.sleep(2000);
		//attendance.CheackAllCheckbox();
		
		attendance.clicksubmitbutton();
//		String actualConfiramationTxt = attendance.verifyConfirmationMessage(); 
//		String expectedConfiramationTxt = "Record Saved Successfully!";
//		System.out.println("Actual Confirmation Text - " + actualConfiramationTxt + "\n"
//				+ "Expected Confiramtion Text - " + expectedConfiramationTxt);
//		Assert.assertEquals(actualConfiramationTxt, expectedConfiramationTxt);

	}//student_TheoryBatchRegistration end

}// StudentAttendanceRegistrationTests class end




















































/*
generalised method call for dropdown function
attendance.dropdown("id", "ddlAttendanceSession","ATTENDANCE SESSION");
attendance.dropdown("id", "ddlBasicCourse","BSC SEM 1");
attendance.dropdown("id", "ddlCourse","BSC SEM 1 - 1");
attendance.dropdown("id", "ddlSubject","HINDI--HINDI(1.00)");
attendance.dropdown("id", "ddlTheoryBatch","BSC TH BATCH");
attendance.dropdown("id", "ddlTeacher","QUALITY ASSURANCE");

//Displaying current time in 12 hour format with AM/PM
    	DateFormat dateFormat = new SimpleDateFormat("hh.mm aa");
    	String dateString = dateFormat.format(new Date()).toString();
    	System.out.println("Current time in AM/PM: "+dateString);

    	//Displaying current date and time in 12 hour format with AM/PM
    	DateFormat dateFormat2 = new SimpleDateFormat("dd/MM/yyyy hh.mm aa");
    	String dateString2 = dateFormat2.format(new Date()).toString();
    	System.out.println("Current date and time in AM/PM: "+dateString2



*/
