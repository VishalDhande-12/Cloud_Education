package com.qa.tests.payroll;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.payroll.MonthlyWork;
import com.qa.pages.payroll.Payroll;
import com.qa.pages.payroll.SalaryProcessing;
import com.qa.utilities.ExcelReader;

public class SalaryProcessingTests extends BaseClass {
	
	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Payroll payroll;
	MonthlyWork monthlyWork;
	SalaryProcessing salaryProcessing;
	

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass() {
}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsAdmin");
		
		System.out.println("\n" + "******Starting Test: " + m.getName() + "*****" + "\n");
	}
	
	@AfterMethod
	public void afterMethod() {
	}
	
	@Test()
	
	public void SalaryProcessing() throws IOException, Exception {
	
		loginPage = new LoginPageAdmin(driver);
		payroll = new Payroll(driver);
		salaryProcessing = new SalaryProcessing(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"), 
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		Thread.sleep(1000);
		homePage.openPayroll();
		
		//acceptAlert();
		Thread.sleep(1000);
		payroll.openTransaction();
		
		Thread.sleep(1000);
		payroll.openMonthlyWork();
		
		Thread.sleep(1000);
		payroll.openSalaryProcess();
		
		Thread.sleep(1000);
		salaryProcessing.selectMonthYear();
		
		Thread.sleep(1000);
		salaryProcessing.ddlStaff();
		
		Thread.sleep(1000);
		salaryProcessing.btnSalaryProcess();
		
		Thread.sleep(1000);
		salaryProcessing.acceptAlert();
		

		
		//Utilities.getAScreenShot();
		
	}
}

		
		
		
		
		
		
	