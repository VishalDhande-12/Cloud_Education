package com.qa.tests.academic;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.academic.Academic;
import com.qa.pages.academic.Registration;
import com.qa.pages.academic.Transaction;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;




public class RegistrationTests extends BaseClass {

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Academic academic;
	Transaction transaction;
	Registration registration;

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass() {

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception {
		
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod() {
	}

	
	


	@Test(priority=1)
	public void Student_Registration() throws IOException, InterruptedException {

		loginPage = new LoginPageAdmin(driver);
		academic = new Academic(driver);
		transaction = new Transaction(driver);
		registration = new Registration(driver);
		
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));

		Thread.sleep(1000);
		homePage.openAcademic();
		
		//acceptAlert();
		Thread.sleep(1000);
		academic.openTransaction();
		
		Thread.sleep(1000);
		transaction.openTabList("Registration And Merit List");
		
		Thread.sleep(1000);
		transaction.openRegistration();
		
		Thread.sleep(1000);
		registration.selectCourse();
		
		Thread.sleep(1000);
		registration.selectSearchCriteria();
		
		Thread.sleep(1000);
		registration.selectTitle();
		
		Thread.sleep(1000);
		registration.enterLastName();
		
		Thread.sleep(1000);
		registration.enterFirstName();
		
		Thread.sleep(1000);
		registration.enterMiddleName();
		
		Thread.sleep(1000);
		registration.selectGender();
		
		Thread.sleep(1000);
		registration.selectCasteCategory();
		
		Thread.sleep(1000);
		registration.enterMothersName();
		
		Thread.sleep(1000);
		registration.enterFathersName();
		
		Thread.sleep(1000);
		registration.enterFormNo();
		
		Thread.sleep(1000);
		registration.enterProvisionalADMNo();
		
		Thread.sleep(1000);
		registration.enterAddress();
		
		Thread.sleep(1000);
		registration.enterEmailId();
		
		Thread.sleep(1000);
		registration.enterStudentMobileNo();
//		registration.enterDOB();
		
		Thread.sleep(1000);
		registration.enterParentMobileNo();
		
		//Payment
		Thread.sleep(1000);
		registration.enterAmount();
		
		Thread.sleep(1000);
		registration.selectPaymentMode();
		
		Thread.sleep(1000);
		registration.enterRemark();
		
		//Submit
		Thread.sleep(1000);
		registration.clickOnSubmit();
		
		Thread.sleep(1000);
		Utilities.getAShot();
		
		Thread.sleep(3000);
		String actualConfirmationTxt = registration.verifyConfirmationMessage();
		String expectedConfirmationTxt = "Saved Successfully!";
		System.out.println("Actual Confirmation Text - " + actualConfirmationTxt + "\n"
				+ "Expected Confirmation Text - " +expectedConfirmationTxt);
		
		Assert.assertEquals(actualConfirmationTxt, expectedConfirmationTxt);
		
	}
	
	
	

	
	
	
}



