package com.qa.tests.academic;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.academic.Academic;
import com.qa.pages.academic.FeesCollection;
import com.qa.pages.academic.OutstandingFees;
import com.qa.pages.academic.StudentAdmission;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;




public class FeesCollectionTests extends BaseClass {

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Academic academic;
	StudentAdmission studentAdmission;
	FeesCollection feesCollection;
	OutstandingFees outstandingFees;
	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass() {

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception {
		
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod() {
	}

	
	


	@Test()
	public void User_Able_To_Perform_Fees_collection() throws IOException, Exception {

		loginPage = new LoginPageAdmin(driver);
		academic = new Academic(driver);
		studentAdmission = new StudentAdmission(driver);
		feesCollection = new FeesCollection(driver);
		outstandingFees = new OutstandingFees(driver);
		
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));

		Thread.sleep(1000);
		homePage.openAcademic();
		
		Thread.sleep(1000);
		//acceptAlert();
		academic.openTransaction();
		
		Thread.sleep(1000);
		academic.openCollectFees();
		
		Thread.sleep(1000);
		academic.openFeesCollection();
		
		
		Thread.sleep(1000);
		/*Fees Collection*/
		feesCollection.SearchCriteria();
		
		Thread.sleep(1000);
		feesCollection.Enterstudentname();
		
		Thread.sleep(1000);
		feesCollection.btnShow();
		
		Thread.sleep(1000);
		feesCollection.acceptAlert();
		
		Thread.sleep(1000);
		feesCollection.EnterMobileNo();
		
		Thread.sleep(1000);
		feesCollection.Remark();
		
		Thread.sleep(1000);
		//feesCollection.scrollIntoView();
		feesCollection.ddlAdmThrough();
		
		Thread.sleep(1000);
		feesCollection.ddlpayoption();
		
		Thread.sleep(1000);
		feesCollection.payid();
		
		Thread.sleep(1000);
		feesCollection.ddlPayMode();
		
		Thread.sleep(1000);
		feesCollection.AmtDesc();
		
		Thread.sleep(1000);
		feesCollection.btnAdd();
		
		Thread.sleep(1000);
		feesCollection.btnAdjust();
		
		Thread.sleep(1000);
		feesCollection.btnSubmitSpan();
		
		String actualConfiramationTxt = feesCollection.verifyConfirmationMessage();
		String expectedConfiramationTxt = "Record Saved Successfully!";
		System.out.println("Actual Confirmation Text - " + actualConfiramationTxt + "\n"
				+ "Expected Confiramtion Text - " + expectedConfiramationTxt);

		Assert.assertEquals(actualConfiramationTxt, expectedConfiramationTxt);
		
		/*Fees Collection*/
		

		//PdfReader.readPdfContent("");
		
		
		Thread.sleep(2000);
		Utilities.getAShot();

		



	}

	


}
