package com.qa.tests.academic;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.academic.Academic;
import com.qa.pages.academic.FeesReports;
import com.qa.pages.academic.OutstandingFeesReport;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;




public class OutsatndingFeesReportTests extends BaseClass {

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Academic academic;
	OutstandingFeesReport outstandingFeesReport;
	FeesReports feesReports;
	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass() {

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception {
		
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod() {
	}

	
	


	@Test()
	public void User_Able_To_Generate_Outstanding_Fees_Report() throws IOException, Exception {

		loginPage = new LoginPageAdmin(driver);
		academic = new Academic(driver);
		feesReports = new FeesReports(driver);
		outstandingFeesReport = new OutstandingFeesReport(driver);
		
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));

		Thread.sleep(1000);
		homePage.openAcademic();
		
		//acceptAlert();
		Thread.sleep(1000);
		academic.openFeesReports();
		
		Thread.sleep(1000);
		feesReports.expandFeesReport();
		
		Thread.sleep(1000);
		feesReports.openOutstandingFeesReport();
		
		Thread.sleep(1000);
		outstandingFeesReport.selectSession();
		
		Thread.sleep(1000);
		outstandingFeesReport.selectReceiptBook();
		
		Thread.sleep(1000);
		outstandingFeesReport.selectBasicCourse();
		
		Thread.sleep(1000);
		outstandingFeesReport.selectCourse();
		//outstandingFeesReport.selectFeeType();
		//outstandingFeesReport.selectStudentType();
		//outstandingFeesReport.selectMedium();
		
		Thread.sleep(1000);
		outstandingFeesReport.selectReportType();
//		outstandingFeesReport.enterPayAmtTillDate();
		
		Thread.sleep(1000);
		outstandingFeesReport.clickOnReport();
		
		Thread.sleep(5000);
		switchToNextWindow();
		
		Thread.sleep(10000);
		Utilities.getAScreenShot();
		

		/*Fees Collection*/
		

	}

	


}
