package com.qa.tests.syty_registration;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageStudent;
import com.qa.pages.LoginPageStudent;
import com.qa.pages.syty_registeration.OnlineRegisteration;
import com.qa.pages.syty_registeration.Personal;

public class SYTYRegisterationTests extends BaseClass {

	LoginPageStudent loginPage;
	HomePageStudent homePage;
	Personal personal;
	OnlineRegisteration onlineRegisteration;
	
	
	InputStream dataIs;
	JSONObject loginUsers;

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass() {

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception {
		driver = initializeDriverBFT("urlCIMSAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod() {
	}

	
	
	
	@Test(priority = 1)
	public void registerationSYTY () throws IOException {

		loginPage = new LoginPageStudent(driver);
		personal = new Personal(driver);
		onlineRegisteration = new OnlineRegisteration(driver);
		

//		homePage = loginPage.login(loginUsers.getJSONObject("SYTYLogin").getString("userName"),
//		loginUsers.getJSONObject("SYTYLogin").getString("password"));
		
		homePage.openOnlineRegisteration();
		onlineRegisteration.openPersonal();
		personal.enterStudentNameTamil();
		personal.selectGender();
		personal.enterMobileNo();
		
		

		
		

	}


}


