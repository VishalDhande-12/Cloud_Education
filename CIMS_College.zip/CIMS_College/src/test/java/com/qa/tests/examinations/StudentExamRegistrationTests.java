package com.qa.tests.examinations;

import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.academic.Academic;
import com.qa.utilities.ExcelReader;

public class StudentExamRegistrationTests  extends BaseClass{

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Academic academic;
	
	InputStream dataIs;
	JSONObject loginUsers;
	
	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	@BeforeClass
	public void beforeClass() throws Exception 
	{
		try
		{
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (dataIs != null) 
			{
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass()
	{
	}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception
	{
		driver = initializeDriverBFT("urlCimsAdmin");
		System.out.println("\n" + "******Starting Test: " + m.getName() + "*******" + "\n");
	}
	
	@AfterMethod
	public void afterMethod()
	{
	}
	
	@Test
	public void User_Students_Available_In_Grid_Registered_For_All_Available_Courses() 
	{
		loginPage = new LoginPageAdmin(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
//		String a = https://cimsuat.mastersofterp.in/ExamStudReg/Index;
//		driver.getCurrentUrl("https://cimsuat.mastersofterp.in/ExamStudReg/Index");
	    driver.findElement(By.id("ddlAcdSession")).click();
	    driver.findElement(By.id("ddlSession")).click();
	    driver.findElement(By.id("ddlBasicCourse")).click();
	    driver.findElement(By.id("ddlCourse")).click();
	    driver.findElement(By.id("ddlMedium")).click();
	    driver.findElement(By.id("ChkAll")).click();
	    driver.findElement(By.id("btnSubmitSpan")).click();
	    driver.findElement(By.id("ChkAll")).click();
	    driver.findElement(By.id("ChkAll")).click();
	    driver.findElement(By.id("btnLockSpan")).click();
	}
	
}
