package com.qa.tests.StudentsCertificates;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.StudentsCertificates.StudentsAcademicUrls;
import com.qa.pages.StudentsCertificates.StudentsTc;
import com.qa.utilities.Utilities;

public class StudentsTcTests extends BaseClass {

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	StudentsAcademicUrls studentsAcademicUrls;
	StudentsTc studentsTc;
	
	InputStream dataIs;
	JSONObject loginUsers;
	
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsStudentsCertificates");
		System.out.println("\n" + "********Starting Test: "+ m.getName() + "******"+ "\n");
	}
	
	@AfterMethod
	public void afterMethod() {
		
	}
	
	@Test()
	
	public void User_Able_To_Generate_Student_Tc() throws IOException, Exception {
		
		loginPage = new LoginPageAdmin(driver);
		studentsAcademicUrls = new StudentsAcademicUrls(driver);
		studentsTc = new StudentsTc(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("CimsStudentsCertificatesLogin").getString("userName"),
				loginUsers.getJSONObject("CimsStudentsCertificatesLogin").getString("password"));
		
		studentsAcademicUrls.openACADEMIC();
		Thread.sleep(1000);
		//acceptAlert();
		studentsAcademicUrls.openStudentReports();
		studentsAcademicUrls.openCertificate();
		studentsAcademicUrls.openStudentTc();
		studentsTc.openddlSession();
		studentsTc.ddlBasicCourse();
		studentsTc.CourseYearStandard();
		studentsTc.ddlSearchBy();
		studentsTc.SearchText();
		
//		Thread.sleep(2000);
//		System.out.println("Enter Name Search Text");
//		driver.findElement(By.id("txtSearch")).sendKeys("___");
//		Thread.sleep(1000);
//		driver.findElement(By.id("txtSearch")).sendKeys(Keys.ARROW_DOWN);
//		Thread.sleep(1000);
//		driver.findElement(By.id("txtSearch")).sendKeys(Keys.ENTER);
//		Thread.sleep(1000);
		
		Thread.sleep(1000);
		acceptAlert();
		studentsTc.btnShow();
		
		Thread.sleep(1000);
		System.out.println("Enter Conduct - Teacher");
		driver.findElement(By.id("txtConduct")).clear();
		driver.findElement(By.id("txtConduct")).sendKeys("Teacher");
		Thread.sleep(1000);
		System.out.println("Enter Progress - InProgress");
		driver.findElement(By.id("txtProgress")).clear();
		driver.findElement(By.id("txtProgress")).sendKeys("InProgress");
		Thread.sleep(1000);
		System.out.println("Enter Reason - Settled In Abroad");
		driver.findElement(By.id("txtReason")).clear();
		driver.findElement(By.id("txtReason")).sendKeys("Settled In Abroad");
		
		scrollIntoView(null, 0, 500);
		
//		studentsTc.txtConduct();
//		studentsTc.txtProgress();
//		studentsTc.txtReason();
		
		studentsTc.ddlTcFormat();
		Thread.sleep(2000);
		studentsTc.btnPreview();

		Thread.sleep(5000);
		switchToNextWindow();
		
		Thread.sleep(10000);
		Utilities.getAScreenShot();
		
	}
}
