package com.qa.tests.syty_registration;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class GoogleTest2 {
	
	public static WebDriver driver;
	@Test
	public void HomePageCheck() throws MalformedURLException, Exception
	{
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setBrowserName("chrome");
//		caps.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
		caps.setCapability(CapabilityType.BROWSER_NAME, "chrome");
		
//		//start headless
//		ChromeOptions chromeOptions = new ChromeOptions();
//		chromeOptions.addArguments("--headless", "--window-size=1920,1200");
//		driver = new ChromeDriver(chromeOptions);
//		//end headless
//		// Execute in chrome driver
		
		
		WebDriver driver = new RemoteWebDriver(new URL("http://172.16.1.57:4444"), caps);
		driver.get("http://google.com");
		System.out.println("driver.getTitle");
		driver.findElement(By.name("q")).sendKeys("Data Science");
		Thread.sleep(5000);
		driver.close();
	}
	

}
