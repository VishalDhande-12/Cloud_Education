package com.qa.tests.attendance;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.attendance.Attendance;
import com.qa.pages.attendance.TheoryBatchCreation;

public class TheoryBatchCreationTests extends BaseClass
{

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
    Attendance attendance;
    TheoryBatchCreation theorybatch;
	InputStream dataIs;
	JSONObject loginUsers;

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception 
	{
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass()
	{

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception
	{
		driver = initializeDriverBFT("urlCimsAdmin");
		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
		loginPage = new LoginPageAdmin(driver);
		attendance = new Attendance(driver);
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));

	}

	
	
	@AfterMethod
	public void afterMethod()
	{
	}

	
	
	

	@Test(priority = 1)
	public void User_Able_To_Create_Theory_Batch () throws IOException, InterruptedException 
	{
		theorybatch =new TheoryBatchCreation(driver);
		Thread.sleep(1000);
		homePage.openAttendance();
		
		Thread.sleep(1000);
		attendance.OpenMaster();
		
		Thread.sleep(1000);
		attendance.OpenBatch();
		
		Thread.sleep(1000);
		theorybatch.OpenTheoryBatch();
		
		Thread.sleep(2000);
		attendance.SelectAttendanceSession();
		
		Thread.sleep(2000);
		theorybatch.EnterTheoryBatchShortName();
		
		Thread.sleep(1000);
		theorybatch.EnterTheoryBatchName();
		
		Thread.sleep(1000);
		attendance.ClickSubmitbutton();
		//attendance.ClickHomeIcon();

	}//Attendance_TheorybatchCreation end


}// StudentAttendanceRegistrationTests class end






















































//generalised method call for dropdown function
//attendance.dropdown("id", "ddlAttendanceSession","ATTENDANCE SESSION");
//attendance.dropdown("id", "ddlBasicCourse","BSC SEM 1");
//attendance.dropdown("id", "ddlCourse","BSC SEM 1 - 1");
//attendance.dropdown("id", "ddlSubject","HINDI--HINDI(1.00)");
//attendance.dropdown("id", "ddlTheoryBatch","BSC TH BATCH");
//attendance.dropdown("id", "ddlTeacher","QUALITY ASSURANCE");
