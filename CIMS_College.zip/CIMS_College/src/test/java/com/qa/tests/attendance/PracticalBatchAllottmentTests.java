package com.qa.tests.attendance;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.attendance.Attendance;
import com.qa.pages.attendance.PracticalBatchAllotment;
import com.qa.utilities.Utilities;

public class PracticalBatchAllottmentTests extends BaseClass
{

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
    Attendance attendance;
    PracticalBatchAllotment practicalbatchallot;
	InputStream dataIs;
	JSONObject loginUsers;

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception 
	{
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass()
	{

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception
	{
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod()
	{
	}


	@Test(priority = 1)
	public void User_Able_To_Allot_Partical_Batch () throws IOException, InterruptedException 
	{
		loginPage = new LoginPageAdmin(driver);
		attendance = new Attendance(driver);
		practicalbatchallot = new PracticalBatchAllotment(driver);
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		Thread.sleep(1000);
		homePage.openAttendance();
		
//		attendance.OpenMaster();
		Thread.sleep(1000);
		attendance.OpenTransaction();
		
		Thread.sleep(1000);
		attendance.OpenRegistration();
		
		Thread.sleep(1000);
		practicalbatchallot.OpenPracticalBatchAllottment();
		
		Thread.sleep(1000);
		attendance.SelectAttendanceSession();
		
		Thread.sleep(2000);
		attendance.SelectBasiccourse();
		
		Thread.sleep(1000);
		attendance.SelectCourse("BSC SEM 1 - 1");
		
		Thread.sleep(2000);
		attendance.SelectTheoryBatch();
		
		Thread.sleep(1000);
		attendance.SelectPracticalBatch();
		
		Thread.sleep(1000);
		attendance.CheackAllCheckbox();
		
		Thread.sleep(1000);
		attendance.ClickSubmitbutton();
		
		Thread.sleep(1000);
		Utilities.getAShot();
		
	}//student_PracticalBatchRegistration end


}// StudentAttendanceRegistrationTests class end



