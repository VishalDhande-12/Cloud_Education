package com.qa.tests.StudentsCertificates;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.StudentsCertificates.StudentIDCardBackPrint;
import com.qa.pages.StudentsCertificates.StudentsAcademicUrls;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;

public class StudentIDCardBackPrintTests extends BaseClass {
	
	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	StudentsAcademicUrls studentsAcademicUrls;
	StudentIDCardBackPrint studentIDCardBackPrint;

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass() {
}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsStudentsCertificates");
		
		System.out.println("\n" + "******Starting Test: " + m.getName() + "*****" + "\n");
	}
	
	@AfterMethod
	public void afterMethod() {
	}
	
	@Test()
	
	public void User_Able_To_Generate_Student_IDCard_BackSide_Print_Tests() throws IOException, Exception {
	
		loginPage = new LoginPageAdmin(driver);
		studentsAcademicUrls = new StudentsAcademicUrls(driver);
		studentIDCardBackPrint = new StudentIDCardBackPrint(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"), 
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		studentsAcademicUrls.openACADEMIC();
		Thread.sleep(1000);
		//acceptAlert();
		studentsAcademicUrls.openStudentReports();
		studentsAcademicUrls.openCertificate();
		studentsAcademicUrls.openStudentIDCard();
		studentIDCardBackPrint.openddlSession();
		studentIDCardBackPrint.ddlCourse();
		studentIDCardBackPrint.ddlSearchBy();
		Thread.sleep(2000);
		studentIDCardBackPrint.userInput();
		Thread.sleep(2000);
		studentIDCardBackPrint.btnBack();
		
		//driver.close();

		
	
		Thread.sleep(5000);
		switchToNextWindow();
		
		Thread.sleep(10000);
		Utilities.getAScreenShot();
		
	}
}

		
		
		
		
		
		
	