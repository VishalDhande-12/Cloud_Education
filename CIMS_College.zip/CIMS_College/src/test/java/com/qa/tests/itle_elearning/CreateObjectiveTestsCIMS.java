package com.qa.tests.itle_elearning;

import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.itle.CreateObjective;
import com.qa.pages.itle.Create_Objective_test_CIMS_Link;
import com.qa.pages.itle.SelectCourse;

public class CreateObjectiveTestsCIMS extends BaseClass {

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Create_Objective_test_CIMS_Link itleAdmin;
    SelectCourse selectCourse;
	InputStream dataIs;
	JSONObject loginUsers;
	CreateObjective createObjective;

	public static WebDriver driver;
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	@AfterClass
	public void afterClass() {

	}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception {
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	@AfterMethod
	public void afterMethod() {
	}

	@Test(priority = 1)

	public void Faculty_Should_Be_Able_To_Create_Objective_Test_Paper () throws Exception {

   
		loginPage = new LoginPageAdmin(driver);
		itleAdmin = new Create_Objective_test_CIMS_Link(driver);
		selectCourse = new SelectCourse(driver);
		createObjective = new CreateObjective(driver);
		

		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		Thread.sleep(1000);
		homePage.openItle();
		
		Thread.sleep(1000);
		//acceptAlert();
		itleAdmin.openCourceSubject();
		
		Thread.sleep(1000);
		itleAdmin.openSelectCourseSubject();
		
		Thread.sleep(1000);
		itleAdmin.openSelectCourseSubject1();
		
		Thread.sleep(1000);
		itleAdmin.select_ITLE_Session();
		
		Thread.sleep(1000);
		itleAdmin.select_Course();
		
		Thread.sleep(1000);
		itleAdmin.openEnglishSubject();
		
		Thread.sleep(1000);
		itleAdmin.Test();
		
		Thread.sleep(1000);
		itleAdmin.createTest();
		
		Thread.sleep(1000);
		itleAdmin.enterTestTitle();
		
		Thread.sleep(1000);
		itleAdmin.testScheduleType();
		
		Thread.sleep(1000);
		itleAdmin.selectTestStartDate();
		
//		Thread.sleep(1000);
//		itleAdmin.selectTest_End_Date();
		
		Thread.sleep(1000);
		itleAdmin.enterTestDuration();
		
		Thread.sleep(1000);
		itleAdmin.selectStartTime();
		
		Thread.sleep(1000);
		itleAdmin.selectQuestionType();
		
		Thread.sleep(1000);
		itleAdmin.SetQuestionPaper();
		
		Thread.sleep(1000);
		itleAdmin.EnterNoOfPaperSets();
		
		Thread.sleep(1000);
		itleAdmin.EnterEasyQuestion();
		
		Thread.sleep(4000);
		itleAdmin.EnterObjectiveMarkPerStudent();
		
		Thread.sleep(1000);
		itleAdmin.clickOnSubmitButton();
		
		Thread.sleep(1000);
		itleAdmin.OpenAssignExam();
		
		Thread.sleep(1000);
		itleAdmin.AssignExamCheckBox();
		
		Thread.sleep(1000);
		itleAdmin.clickOnOkButton();
		
		Thread.sleep(1000);
		itleAdmin.clickOnAfterResultOn();
		
		Thread.sleep(2000);
		System.out.println("Allow Student to Continue Exam After End Time?");
		driver.findElement(By.id("IsAllowredretest")).click();
		
		Thread.sleep(2000);
		itleAdmin.clickOnSaveButton();
		
		Thread.sleep(5000);
//		String alertMessage= driver.switchTo().alert().getText(); // capture alert message
//		System.err.println(alertMessage);
		
		
//		WebDriverWait wait = new WebDriverWait(driver, 10);
//
//		try {
//		    wait.until(ExpectedConditions.alertIsPresent());
//		    Alert alert = driver.switchTo().alert();
//		    alert.accept();
//		    System.err.println("Alert was present and accepted");
//		    System.err.println("Test Already Exists. Please Create Different Test.");
//		    System.err.println(alert);
//		    }
//		catch(Exception e) {
////			wait.until(ExpectedConditions.alertIsPresent());
////		    Alert alert = driver.switchTo().alert();
////		    alert.accept();
////			System.err.println(alert);
//		    System.out.println("Alert was not present");
//		    System.out.print(e);
//		   // driver.logout.click();
//		}
		
	}
	
}
