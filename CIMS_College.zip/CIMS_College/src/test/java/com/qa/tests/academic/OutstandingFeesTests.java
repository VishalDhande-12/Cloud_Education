package com.qa.tests.academic;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.academic.Academic;
import com.qa.pages.academic.FeesCollection;
import com.qa.pages.academic.OutstandingFees;
import com.qa.pages.academic.StudentAdmission;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;




public class OutstandingFeesTests extends BaseClass {

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Academic academic;
	StudentAdmission studentAdmission;
	FeesCollection feesCollection;
	OutstandingFees outstandingFees;
	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass() {

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception {
		
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod() {
	}

	@Test()
	
	public void User_Able_To_Collect_Outstanding_fees() throws IOException, Exception {

		loginPage = new LoginPageAdmin(driver);
		academic = new Academic(driver);
		studentAdmission = new StudentAdmission(driver);
		feesCollection = new FeesCollection(driver);
		outstandingFees = new OutstandingFees(driver);
		
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));

		homePage.openAcademic();
		//acceptAlert();
		academic.openTransaction();
		academic.openCollectFees();
		academic.openOutstandingFees();
		
		/*Outstanding Fees */
		Thread.sleep(1000);
		outstandingFees.ddlBasicCourseBranchStandard();
		Thread.sleep(1000);
		outstandingFees.CourseYearStandard();
		Thread.sleep(1000);
		outstandingFees.SearchBy();
		Thread.sleep(1000);
		outstandingFees.serchtext();
		Thread.sleep(1000);
		outstandingFees.btnShowSpan();
		Thread.sleep(1000);
		outstandingFees.acceptAlert();

		Thread.sleep(1000);
		outstandingFees.Remark();
		Thread.sleep(1000);
		outstandingFees.PaymentOption();
		Thread.sleep(1000);
		outstandingFees.PaymentID();
		Thread.sleep(1000);
		outstandingFees.ReceiptMode();
		Thread.sleep(1000);
		outstandingFees.PaymentMode();
		Thread.sleep(1000);
		outstandingFees.amount();
		Thread.sleep(1000);
		outstandingFees.btnAddAmt();
		Thread.sleep(1000);
		outstandingFees.btnAdjust();
		Thread.sleep(1000);
		outstandingFees.btnSubmitSpan();
		
		Thread.sleep(2000);
		String actualConfiramationTxt = outstandingFees.verifyConfirmationMessage();
		String expectedConfiramationTxt = "Records Saved Successfully!";
		System.out.println("Actual Confirmation Text - " + actualConfiramationTxt + "\n"
				+ "Expected Confiramtion Text - " + expectedConfiramationTxt);
		Assert.assertEquals(actualConfiramationTxt, expectedConfiramationTxt);
		
		Thread.sleep(5000);
		switchToNextWindow();
		
		Thread.sleep(10000);
		driver.manage().window().maximize();
		Utilities.getAScreenShot();
		//PdfReader.readPdfContent("");
		
		//outstandingFees.Download();
		
		/*Outstanding Fees */
		
		

		

		
//
//		String actualConfiramationTxt = studentAdmission.verifyConfirmationMessage();
//		String expectedConfiramationTxt = "Record Saved Successfully!";
//		System.out.println("Actual Confirmation Text - " + actualConfiramationTxt + "\n"
//				+ "Expected Confiramtion Text - " + expectedConfiramationTxt);
//
//		Assert.assertEquals(actualConfiramationTxt, expectedConfiramationTxt);

	}

	


}
