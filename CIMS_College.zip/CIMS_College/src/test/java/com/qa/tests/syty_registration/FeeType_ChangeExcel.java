package com.qa.tests.syty_registration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class FeeType_ChangeExcel {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		 //Create an object of File class to open xlsx file
        File file =    new File(".\\src\\test\\resources\\excel\\MCCJUNIOR_SUPPORT6@PTVA.COM_JxiZWpea.xlsx");
        
        //Create an object of FileInputStream class to read excel file
        FileInputStream inputStream = new FileInputStream(file);
        
        //Creating workbook instance that refers to .xls file
        HSSFWorkbook wb=new HSSFWorkbook(inputStream);
        
        //Creating a Sheet object using the sheet Name
        HSSFSheet sheet=wb.getSheet("MCCJUNIOR_SUPPORT6@PTVA");
        
        //Create a row object to retrieve row at index 1
        HSSFRow row2=sheet.getRow(5);
        
        //Create a cell object to retreive cell at index 5
        HSSFCell cell=row2.getCell(3);
        
        //Get the address in a variable
        String Studentid= cell.getStringCellValue();
        
        //Printing the address
        System.out.println("StudentId is :"+ Studentid);
	}

}
