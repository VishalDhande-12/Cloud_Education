package com.qa.tests.establishment;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.establishment.Establishment;
import com.qa.pages.establishment.LeaveDetails;
import com.qa.utilities.ExcelReader;

public class LeaveDetailsTests extends BaseClass {
	
	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Establishment establishment;
	LeaveDetails leaveDetails;

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass() {
}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsAdmin");
		
		System.out.println("\n" + "******Starting Test: " + m.getName() + "*****" + "\n");
	}
	
	@AfterMethod
	public void afterMethod() {
	}
	
	@Test()
	
	public void LeaveDetails() throws IOException, Exception {
	
		loginPage = new LoginPageAdmin(driver);
		establishment = new Establishment(driver);
		leaveDetails = new LeaveDetails(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"), 
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		homePage.openEstablishment();
		acceptAlert();
		establishment.openTransaction();
		establishment.openLeaveTransaction();
		establishment.openLeaveDetails();
		leaveDetails.btnAddNew();
		leaveDetails.ddlLeaveName();
		//leaveDetails.LeaveDays();
		leaveDetails.ddlStaffType();
		leaveDetails.ddlPeriod();
		leaveDetails.MaxDays();
		leaveDetails.btnSubmit();
		
		
		
		
		//Utilities.getAScreenShot();
		
	}
}

		
		
		
		
		
		
	