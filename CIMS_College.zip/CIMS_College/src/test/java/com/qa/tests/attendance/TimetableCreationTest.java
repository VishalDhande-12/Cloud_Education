package com.qa.tests.attendance;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.attendance.Attendance;
import com.qa.pages.attendance.TimetableCreation;

public class TimetableCreationTest extends BaseClass
{

	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Attendance attendance;
	TimetableCreation attendancetimetable;
	InputStream dataIs;
	JSONObject loginUsers;

	public static WebDriver driver;
	
	

	@BeforeClass
	public void beforeClass() throws Exception 
	{
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}

	
	
	@AfterClass
	public void afterClass()
	{

	}
	
	

	@BeforeMethod
	public void beforeMethod(Method m) throws Exception
	{
		driver = initializeDriverBFT("urlCimsAdmin");

		System.out.println("\n" + "***** Starting Test: " + m.getName() + "*****" + "\n");
	}

	
	
	@AfterMethod
	public void afterMethod()
	{
	}

	
	
	

	@Test(priority = 1)
	public void User_Able_To_Create_Timetable () throws IOException, InterruptedException 
	{
		loginPage = new LoginPageAdmin(driver);
		attendance = new Attendance(driver);
		attendancetimetable = new TimetableCreation(driver);
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"),
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		homePage.openAttendance();
		attendance.OpenTransaction();
		attendancetimetable.OpenTimetable();
		attendancetimetable.OpenTimetableCreation();
		attendance.SelectAttendanceSession();
		attendance.SelectBasiccourse();
		attendance.SelectCourse("BSC SEM 1 - 1");
		attendancetimetable.SelectSubject("ENGLISH--ENGLISH(0.00)");
		attendancetimetable.SelectDay("MONDAY");
		attendancetimetable.SelectSlot("10:00AM-11:00AM");
		attendancetimetable.SelectRoom("1");

//		attendancetimetable.DragAndDrop();
		Thread.sleep(2000);
		attendance.ClickSubmitbutton();

	}//Attendance_TimetableCreation end


}// StudentAttendanceRegistrationTests class end






















































//generalised method call for dropdown function
//attendance.dropdown("id", "ddlAttendanceSession","ATTENDANCE SESSION");
//attendance.dropdown("id", "ddlBasicCourse","BSC SEM 1");
//attendance.dropdown("id", "ddlCourse","BSC SEM 1 - 1");
//attendance.dropdown("id", "ddlSubject","HINDI--HINDI(1.00)");
//attendance.dropdown("id", "ddlTheoryBatch","BSC TH BATCH");
//attendance.dropdown("id", "ddlTeacher","QUALITY ASSURANCE");
