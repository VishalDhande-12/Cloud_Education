package com.qa.tests.payroll;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.payroll.BasicDetails;
import com.qa.pages.payroll.EmployeeInformation;
import com.qa.pages.payroll.Payroll;
import com.qa.utilities.ExcelReader;

public class EmployeeInformationTests extends BaseClass {
	
	LoginPageAdmin loginPage;
	HomePageAdmin homePage;
	Payroll payroll;
	EmployeeInformation employeeInformation;
	BasicDetails basicDetails;

	InputStream dataIs;
	JSONObject loginUsers;

	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass() {
}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsAdmin");
		
		System.out.println("\n" + "******Starting Test: " + m.getName() + "*****" + "\n");
	}
	
	@AfterMethod
	public void afterMethod() {
	}
	
	@Test()
	
	public void EmployeeInformation() throws IOException, Exception {
	
		loginPage = new LoginPageAdmin(driver);
		payroll = new Payroll(driver);
		basicDetails = new BasicDetails(driver);
		employeeInformation = new EmployeeInformation(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("AdmissionLogin").getString("userName"), 
				loginUsers.getJSONObject("AdmissionLogin").getString("password"));
		
		Thread.sleep(1000);
		homePage.openPayroll();
		
		//acceptAlert();
		Thread.sleep(1000);
		payroll.openTransaction();
		
		Thread.sleep(1000);
		payroll.openBasicDetails();
		
		Thread.sleep(1000);
		basicDetails.openEmployeeInformation();
		
		Thread.sleep(1000);
		employeeInformation.ddlTitle();
		
		Thread.sleep(1000);
		employeeInformation.Sequence();
		
		Thread.sleep(1000);
		employeeInformation.LastName();
		
		Thread.sleep(1000);
		employeeInformation.FirstName();
		
		Thread.sleep(2000);
		employeeInformation.MiddleName();
		
		Thread.sleep(1000);
		employeeInformation.ddlGender();
		
		Thread.sleep(1000);
		employeeInformation.selectDOB();
		
		Thread.sleep(1000);
		employeeInformation.Aadhar();
		
		Thread.sleep(1000);
		employeeInformation.PersonalEmail();
		
		Thread.sleep(1000);
		employeeInformation.Mobile();
		
		Thread.sleep(1000);
		employeeInformation.Email();
		
		Thread.sleep(1000);
		employeeInformation.ddlStaff();
		
		Thread.sleep(1000);
		employeeInformation.ddlDepartment();
		
		Thread.sleep(1000);
		employeeInformation.ddlDesignation();
		
		Thread.sleep(1000);
		employeeInformation.ddlStaffType();
		
		Thread.sleep(1000);
		employeeInformation.ddlAppointment();
		
		Thread.sleep(1000);
		employeeInformation.ddlDesignationNature();
		
		Thread.sleep(1000);
		employeeInformation.ddlUserType();
		
		Thread.sleep(1000);
		employeeInformation.ddlEmployeeType();
		
//		employeeInformation.selectDateofJoin();
		
		//employeeInformation.selectDateofIncrement();
		//employeeInformation.DateofRetire();
		Thread.sleep(1000);
		employeeInformation.DateofMarriage();
		
		Thread.sleep(1000);
		employeeInformation.radioYes();
		
		Thread.sleep(1000);
		employeeInformation.radioHRAYes();
		
		Thread.sleep(1000);
		employeeInformation.ddlBank();
		
		Thread.sleep(1000);
		employeeInformation.AccNo();
		
		Thread.sleep(1000);
		employeeInformation.bankbranch();
		
		Thread.sleep(1000);
		employeeInformation.PANNo();
		
		Thread.sleep(1000);
		employeeInformation.UANNo();
		
		Thread.sleep(1000);
		employeeInformation.IFSCCode();
		
		Thread.sleep(1000);
		employeeInformation.ddlPayRule();
		
		Thread.sleep(2000);
		employeeInformation.ddlpayLevel();
		
		Thread.sleep(2000);
		employeeInformation.ddlCellNo();
		
		Thread.sleep(1000);
		driver.findElement(By.id("txtBasic")).sendKeys("100");
		
		Thread.sleep(1000);
		employeeInformation.btnSubmit();
		
		Thread.sleep(1000);
		employeeInformation.acceptAlert();
		//employeeInformation.btnReport();
		
		//Utilities.getAScreenShot();
		
	}
}

		
		
		
		
		
		
	