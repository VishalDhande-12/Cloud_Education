package com.qa.tests.StudentPortal;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClass;
import com.qa.pages.HomePageAdmin;
import com.qa.pages.HomePageStudent;
import com.qa.pages.LoginPageAdmin;
import com.qa.pages.LoginPageStudent;
import com.qa.pages.StudentPortal.DashboardLinks;
import com.qa.pages.StudentPortal.PhotoAndSign;
import com.qa.pages.StudentPortal.Profile;
import com.qa.pages.StudentPortal.ProfileAddress;
import com.qa.pages.StudentPortal.StudentDocumentsUpload;
import com.qa.utilities.ExcelReader;
import com.qa.utilities.Utilities;

public class ProfileTest extends BaseClass {
	
	LoginPageStudent loginPage;
	HomePageStudent homePage;
	DashboardLinks dashboardLinks;
	Profile profile;
	ProfileAddress profileAddress;
	PhotoAndSign photoAndSign;
	StudentDocumentsUpload studentDocumentsUpload;
	
	InputStream dataIs;
	JSONObject loginUsers;
	
	ExcelReader excelreader;
	
	public static WebDriver driver;
	
	@BeforeClass
	public void beforeClass() throws Exception {
		try {
			String dataFileName = "data/loginUsers.json";
			dataIs = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(dataIs);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (dataIs != null) {
				dataIs.close();
			}
		}
	}
	
	@AfterClass
	public void afterClass() {
	}
	
	@BeforeMethod
	public void beforeMethod(Method m) throws Exception{
		
		driver = initializeDriverBFT("urlCimsStudent");
		
		System.out.println("\n" + "*******Starting Test : Student Portal : " + m.getName() + "*******" + "\n");
			}
	
	@AfterMethod
	public void afterMethod() {
	}
	
	@Test()
	
	public void Profile() throws IOException, Exception {
		
		loginPage = new LoginPageStudent(driver);
		dashboardLinks = new DashboardLinks(driver);
		profile = new Profile(driver);
		profileAddress = new ProfileAddress(driver);
		photoAndSign = new PhotoAndSign(driver);
		studentDocumentsUpload = new StudentDocumentsUpload(driver);
		
		homePage = loginPage.login(loginUsers.getJSONObject("CIMSLogin").getString("userName"),
				loginUsers.getJSONObject("CIMSLogin").getString("password"));
		
//		//Personal Details**********
		dashboardLinks.openProfileLink();
		
//		profile.ddlGender();
//		profile.mobileNo();
//		profile.ddlCasteCategory();
//		profile.ddlNationality();
//		profile.dob();
//		profile.ddlReligion();
//		profile.AdharNo();
//		profile.ddlOccupation();
//		profile.btnSubmitPersonal();
//		//Personal Details**********
//		
////		//Profile Address**********
//		profileAddress.AddressUrl();
//		Thread.sleep(2000);
//		profileAddress.ddlCountry();
//		profileAddress.ddlState();
//		profileAddress.ddlDistrict();
//		profileAddress.ddlCity();
//		profileAddress.txtCity();
//		profileAddress.ParmanentAdd();
//		Thread.sleep(1000);
//		profileAddress.chkSameParmanent();
//		profileAddress.btnSubmitAddress();
////		//Profile Address**********
		
//		//Photo and Signature Details***********
		photoAndSign.PhotoAndSignUrl();
		photoAndSign.btnCropPhotoSelectFile();
		photoAndSign.btnCropSignSelectFile();
		photoAndSign.btnSubmit();
//		//Photo and Signature Details***********
		
		//Subject Details***********
		//Subject Details***********
		
		//Student Documents Upload***********
		Thread.sleep(2000);
		studentDocumentsUpload.SelectDocumentsUploadUrl();
		Thread.sleep(2000);
		studentDocumentsUpload.DocumentsUpload();
		studentDocumentsUpload.Browse();
		studentDocumentsUpload.btnSubmitDoc();
		//Subject Documents Upload***********
		
		Utilities.getAScreenShot();
	}

}
